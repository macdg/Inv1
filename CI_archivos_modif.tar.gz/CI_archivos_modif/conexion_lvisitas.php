<?php
class Conectar1 {

	public static function con() {
		//Nueva sintaxis.  mysqli_connect('servidor-sistema', 'usuario', 'pass', 'db');
		$conexion_mysqli = mysqli_connect('localhost', 'root', '', 'usuarios');
		if ($conexion_mysqli == NULL) {
			echo '<br><hr><h1>'.'[ERROR 8600 "mysqli_connect==NULL"] NO EXISTE CONEXIÓN (No tiene la base de datos iniciada. El error se origina de Mysql.)<h1><hr>';
		}
		//Nueva sintaxis.  mysqli_query(conexion de mysqli_connect, 'atributo a usar');
		mysqli_query($conexion_mysqli, "SET NAMES 'utf8'");
		return $conexion_mysqli;

		//Estas lineas de abajo inmediatas las comente ya que estas realizan la conexion de la base de datos pero es para versiones anteriores de php, ahora las versiones actuales, por ejemplo; la que ahora estoy trabajando "PHP Version 5.4.41-0+deb7u1", pide alguna solución de código de acceso a la db como lo mostrado arriba.
		// $conexion = mysql_connect('localhost', 'root', '', '(pass)');
		// mysql_query("SET NAMES 'utf8' ");
		// mysql_select_db("trabajo_de_curso");
		// return $conexion;
	}

}

?>
<?php
//***********************************************

class Trabajo {

	//De esta manera corta podemos declarar un atributo de tipo array. Las ventajas de esto, nos ayuda a almacenar distintos tipos de datos, además de muchos tamaños de manera simultanea y dinamica, por ejemplo, poblar con datos a la db que se tenga.
	// private $visitas=array();

	//De manera standarizada por la 3W, se declara el atributo y en el constructor se asigna como arreglo array();.
	private $visitas;

	// Esta es otra manera mas convencional de declarar el atributo como array, practicamente es lo mismo que lo mencionado arriba.
	public function __Construct() {

		$this->visitas = array();
	}

	public function get_visitas() {
		/**
		//$sql = 'SELECT * FROM libro_de_visitas';
		//De igual manera estas líneas fueron comentadas,ya que, como lo mensionado arriba es de versión anterior de php para uso de conexión.
		//mysql_query($sql, Conectar::con());
		//mysql_fetch_assoc se usa para regresar la información en arreglos bidimensionales, en versiones actuales se declara diferente y esta por desaparecer.
		//Esta linea la comente porque ya no me la reconocio la versión de PHP 5.4.41-0+deb7u1.
		//while ($reg = mysql_fetch_assoc($res)) {
		//La manera actual es como sigue:
		 **/
		//Agregado el Order.
		$sql = 'SELECT * FROM libro_de_visitas ORDER BY id DESC';
		//Nueva sintaxis. mysqli_query(conexion de mysqli_connect(En este caso usamos el tipo Parent por el metodo static), 'atributo a usar(En este caso la consulta tal cual)');.
		$res = mysqli_query(Conectar1::con(), $sql);
		//Nueva sintaxis. Esta sustituye a fetch assoc. mysqli_fetch_array($res(El query con la conexión), (atributo definiendo el tipo assoc del arreglo bidimensional) MYSQLI_ASSOC));
		while ($reg = mysqli_fetch_array($res, MYSQLI_ASSOC)) {

			$this->visitas[] = $reg;
		}
		return $this->visitas;
	}

	//******************************************************
	//Para imprimir la segunda parte que es el contenido de la segunda tabla. Solo cuestión de aprendizaje y prueba. Aprovechando para limpiar el código de los comentarios necesarios de arriba.

	// public function get_visitas1() {

	// 	$sql = 'SELECT * FROM libro_de_visitas1';
	// 	$res = mysqli_query(Conectar::con(), $sql);
	// 	while ($reg = mysqli_fetch_array($res, MYSQLI_ASSOC)) {

	// 		$this->visitas[] = $reg;
	// 	}
	// 	return $this->visitas;
	// }

	// ***Todo lo comentado simple, es de lo q corresponde al ejercicio anterior y no se requiere aquí.***
	public function add_visitas($nom, $texto) {
		//NOTA: Como el valor del indice es autoincremental, entonces se se coloca como nulo, sin embargo las versiones actuales aceptan tambien un simple numero cero y no se ve afectado el valor de autoincrementar en la base de datos.
		$sql = "INSERT INTO libro_de_visitas VALUES (NULL,'$nom','$texto',now(),now())";
		$res = mysqli_query(Conectar1::con(), $sql);
		echo '<script type="text/javascript">
alert("Gracias por escribir en mi Libro de Visitas");
window.location="libro_visitas.php";
		</script>';
	}

	public function get_visitas_por_id($id) {

		$sql = "SELECT * FROM libro_de_visitas WHERE id=$id";
		$res = mysqli_query(Conectar1::con(), $sql);
		while ($reg = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
			$this->visitas[] = $reg;
		}
		return $this->visitas;

	}

}
?>