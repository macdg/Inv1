<?php
//error_reporting(E_ALL^E_NOTICE^E_WARNING);
require_once ('conexion_lvisitas.php');
$tra = new Trabajo();
//$val_id    = $_GET['id'];
//print_r($_POST['id']);
$reg = $tra->get_visitas_por_id($_GET['id']);
?>
<!DOCTYPE HTML PUBLIC "~//W3C // DTD HTML 4.01 Transitional // EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Editar registros</title>
<!-- Nota:                                        Las rutas de POO es igual sin diagonales al principio y al final.  -->
<script type="text/javascript" language="javascript" src="js/funciones.js"> </script>
</head>

<body onload="limpiar();">
<!-- <center> -->
<form name="form" action="ingresar.php" method="post">
<table width="500" align="center">

<tr>
<td align="center" valign="top" colspan="2">
<h2>Editar Registro</h2>
</td>
</tr>

<tr>
<td valign="top" align="left">
Su nombre
</td>


<td valign="top" align="left"  >
<input type="text" name="nom" value="<?php echo $reg[0]['nombre de persona'];?>"/>
</td>
</tr>

<tr>
<td valign="top" align="left">
Su mensaje

<td valign="top" align="left">
<textarea name="texto" cols="50" row="5"><?php echo $reg[0]['texto'];?> </textarea> <type="text" name="nom" />
</td>
</tr>



<tr>
<td valign="top" width="400" align="center" colspan="2">
<hr/>
<input type="hidden" name="id" value="<?php echo $_GET['id'];?> ">
<input type="button" value="Volver" title="Volver" onclick="window.location='libro_visitas1.php';">
&nbsp;
&nbsp;
||&nbsp;
&nbsp;

<input type="button" value="Editar" title="Editar" onclick="validar();" />
</td>
</tr>

</table>
</form>






</body>
</html>