<?php
//if (!defined('BASEPATH') OR exit('No direct script access allowed')) {;
// }

class Up_xml_controller1 extends CI_Controller {

//private $datos_del_string=array();

public function __construct() {
parent::__construct();
$this->load->helper('file');
$this->load->helper('form','url');
$this->load->helper('directory');
$this->load->model('Up_xml_model');
		$this->load->model('Up_xml_model','up_xml_model');

	}

	public function index() {
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);


		echo '<br>';
		echo '--------------------'.'<br>';
		

		// MANEJANDO LOS ARCHIVOS
$ruta_archivo = '/root/Documentos/rep_xml/';
echo '<br>'.'<br>'.'<br>';
//print_r($_FILES['mi_archivo_1']);
echo '<br>'.'<br>'.'<br>';
//var_dump($_FILES['mi_archivo_1']);

$mi_archivo_1=$_FILES['mi_archivo_1'];
$tip_arch=$mi_archivo_1['name'];
echo 'El nombre del archivo es: '.$tip_arch;
echo '<br>'.'<br>';

$val_ext=substr($tip_arch,-4);
echo '($val_ext) Extension d archivo: '.$val_ext;





if (is_uploaded_file($_FILES['mi_archivo_1']['tmp_name']))
{
 $nombreDirectorio = "/var/www/html/ci/uploads/";
 $nombreFichero = $_FILES['mi_archivo_1']['name'];
 
$nombreCompleto = $nombreDirectorio . $nombreFichero;
 


 	if (file_exists($nombreDirectorio.$nombreFichero)) {
			//echo '<br>'.'El archivo: "'.$nombreFichero.'",ya existe'. 'Seleccione otro archivo.';
		// $this->load->view('up_x');
			$salida='up_xml_controller/index';
//		return ($this->load->view('up_xml_view'));
		} 

			move_uploaded_file($_FILES['mi_archivo_1']['tmp_name'], $nombreDirectorio.$nombreFichero);
 
 }
 
else
 print ("No se ha podido subir el fichero");


// foreach ($todos_archivos as $key => $value) {
//  echo '<br>Todos los archivos: '.$todos_archivos.'Key: '.$key.'Valor: '.$value;
// }

// //Todos los archivos: ArrayKey: 0Valor: NEO0303288Z1FB8410.xml


// echo "<br><hr/>";

// print_r($todos_archivos['0']);
// echo '<br>';
// print_r($todos_archivos['1']);
// echo "<br><hr/>";



echo '<br>Este es el contenido del archivo subido';
echo "<br><hr/>";
echo '<br>';
$this->load->helper('xml2array');
$contents = xml2array(file_get_contents($nombreDirectorio.$nombreFichero));
echo 'Contenido:'. print_r($contents,1);
echo '<br><br><hr/>';


//**********************************************************
//Para imprimir contenido en tablas.
$contents= file_get_contents($nombreDirectorio.$tip_arch);
 $result = xml2array($contents,1,'attribute');
// print_r($result);
//**********************************************************

		//// $result2 = $result;
		//// $result2['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'] = 
		//// array($result2['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);

// print_r($result['cfdi:Comprobante']['cfdi:Conceptos']);
// print_r($result2['cfdi:Comprobante']['cfdi:Conceptos']);
echo "<br>";
		//// $result3 = $result;
		//// $result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital'] = 
		//// array($result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']);


// $contents= file_get_contents('/var/www/html/ci/uploads/NEO0303288Z1FB8410.xml');
// $result = xml2array($contents,1,'attribute');
// print_r($result['cfdi:Comprobante']['cfdi:Conceptos']);


//         CASO DE UN PRODUCTO DENTRO DE LA FACTURA.
// Datos de Concepto.

foreach (($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']) as $key => $value) {
	//echo '<br>###Nivel1 Esto es lo que tiene $result: '.($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']).' $key: '.$key.' $value: '.$value.' ###';

if ($key=='cantidad')
	$cant=$value;
$cantidad=$cant;
if ($key=='unidad')
$unidad=$value;
if ($key=='noIdentificacion')
$no_ident=$value;
if ($key=='descripcion')
$descrip=$value;
if ($key=='valorUnitario')
$val_unit=$value;

}

// Datos de TimbreFiscalDigital.
// Concepto - UUID.

foreach ($result['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']['attr'] as $key => $value) {
// //	echo '<br>%%%Nivel2 Esto es lo que tiene $result: '.$result['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']['attr'].' $key: '.$key.' $value: '.$value.' %%%';

if ($key=='UUID')
	$uuid=$value;
$id_uuid=$uuid;

}


//   Datos del Proveedor.
// Proveedor - RFC.
// Extraidos de Factura para no repetir código.
// $rfc; y $rfc_nom;

foreach ($result['cfdi:Comprobante']['cfdi:Emisor']['cfdi:DomicilioFiscal']['attr'] as $key => $value) {

if ($key=='calle')
	$calle=$value;
if ($key=='noExterior')
	$no_ext=$value;
if ($key=='noInterior')
	$no_int=$value;
if ($key=='colonia')
	$colonia=$value;
if ($key=='referencia')
	$referen=$value;
if ($key=='municipio')
	$mun=$value;
if ($key=='estado')
	$estado=$value;
if ($key=='pais')
	$pais=$value;
if ($key=='codigoPostal')
	$cp=$value;


}


//   Datos de Factura.
// Factura - RFC.
foreach ($result['cfdi:Comprobante']['cfdi:Emisor']['attr'] as $key => $value) {

if ($key=='rfc')
	$id_rfc=$value;
if ($key=='nombre')
	$rfc_nom=$value;

}

// Factura - Desglose.
// Fctura - ['attr'].

foreach ($result['cfdi:Comprobante']['attr'] as $key => $value) {

if ($key=='fecha')
	$fecha=$value;
if ($key=='subTotal')
	$subtotal=$value;
if ($key=='Moneda')
	$moneda=$value;
if ($key=='total')
	$total=$value;

}


//===============================================================
//========   INSERTANDO DATOS ===================================

// $this->up_xml_model->concepto_data_insert(
// 	$id_uuid,
// 	$cantidad,
// 	$unidad,
// 	$no_ident,
// 	$descrip,
// 	$val_unit
// 	);

// $this->up_xml_model->proveedor_data_insert(
// 	$id_rfc,
// 	$rfc_nom,
// 	$calle,
// 	$no_ext,
// 	$no_int,
// 	$colonia,
// 	$referen,
// 	$mun,
// 	$estado,
// 	$pais,
// 	$cp
//  );

// $this->up_xml_model->factura_data_insert(
// 	$id_rfc,
// 	$rfc_nom,
//  $fecha,
// 	$subtotal,
//  $moneda,
// 	$total
//  );




//===============================================================

//            CASO DE MAS PRODUCTOS DENTRO DE LA FACTURA.
//echo '<br>@@@@@@  UUID:= '.$uuid.'  @@@@@@<br>';

$key_search='attr';
$si_existe_key=array_key_exists($key_search,$result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);
// echo '<br><br>$si_existe_key: '.$si_existe_key;


// echo '<br>@@@@@@ Imprimiendo Indices de Arreglos@@@@@@<br>';
$nivel3=$result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'];
// print_r(array_keys($nivel3));
echo '<br><br>';

//print_r($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);
if ($si_existe_key==NULL || $si_existe_key==FALSE) {


//*************************************
	$cont=count($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);
// echo '<br><br>$cont: '.$cont;
 foreach ($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'] as $key => $value) {
	//echo '<br>@@@Nivel3 Esto es lo que tiene $result: '.$result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'].' $key: '.$key.' @@@';

// echo '<br><br> ~> '.$key.'<br><br> ~> '.$value;
//*************************************																										

 }


for ($j=0; $j<$cont; $j++){

 	foreach ($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'][$j]['attr'] as $key => $value) {
 		//echo '<br><br>[attr] KEY:= '.$key.'  				|| [attr] VALUE:= '.$value;
 	
if ($key=='cantidad')
$cant=$value;
if ($key=='descripcion')
$descrip=$value;
$cant_1[$j]=$cant;
$descrip_1[$j]=$descrip;
																										} //Fin de For.

 	}

 echo '<br><br>';



echo '<br><br>';
// print_r( array_keys($nivel3));
}
echo '<br><br>';
// echo '$cant'.$cant ;
echo '<br><br>';
// echo '$descripcion'.$descrip;

echo '<br><br>';
// echo '$cont:'.$cont;

$array            = array();
$array['cant']    = $cant;
$array['descrip'] = $descrip;
$array['descrip_xml1'] = $descrip_xml1;
$array['uuid']    = $uuid;
$array['cant_1']		=	$cant_1;
$array['descrip_1']= $descrip_1;


//***********************************************************************
// $cantidad = $this->input->post($datos_in_cantidad);
// echo '<br>Datos in Cantidad:<br>';
// var_dump($cantidad);
// echo '<br>';
// print_r($cantidad);
// echo '<br>';

// $unidad = $this->input->post($datos_in_unidad);
// echo '<br>Datos in Cantidad:<br>';
// var_dump($unidad);
// echo '<br>';
// print_r($unidad);
// echo '<br>';



// =====================================================================
// == Comentando para poder escribir en db almacen en tabla productos.==
// ============================== Para XML1.============================
// $cantidad = $this->input->post('cantidad');
// $unidad = $this->input->post('unidad');
// $modelo = $this->input->post('modelo');
// $descripcion = $this->input->post('descripcion');
// $valorunitario = $this->input->post('valorunitario');
// $fecha_ingreso = $this->input->post('fecha_ingreso');
// $noserie = $this->input->post('noserie');
// $nopieza = $this->input->post('nopieza');
// $this->up_xml_model->productos_data_insert($cantidad, $unidad, $modelo, $descripcion, $valorunitario, $fecha_ingreso, $noserie, $nopieza);
// echo '<br>Insertando Datos...<br>';
// =====================================================================



//=====================================================================
//== Comentando para poder escribir en db almacen en tabla productos.==
//============================== Para XML2.============================
// $cantidad = $this->input->post('cantidad');
// $unidad = $this->input->post('unidad');
// $modelo = $this->input->post('modelo');
// $descripcion = $this->input->post('descripcion');
// $valorunitario = $this->input->post('valorunitario');
// $fecha_ingreso = $this->input->post('fecha_ingreso');
// $noserie = $this->input->post('noserie');
// $nopieza = $this->input->post('nopieza');
// $this->up_xml_model->productos_data_insert($cantidad, $unidad, $modelo, $descripcion, $valorunitario, $fecha_ingreso, $noserie, $nopieza);
// echo '<br>Insertando Datos...<br>';
//=====================================================================







$this->load->view('up_xml_view1', $array);
$this->load->view('up_xml_in_view1a',$cant,$uuid,$array);
$this->load->view('up_xml_in_view1',$cant,$cont,$cant_1,$descrip_1,$array);
// $this->load->view('up_xml_in_view1a',$cant,$uuid,$array);
		echo '<br>';
		// print_r($file_information);
		// echo $file_information;
		echo '<br>';
		
		$this->output->enable_profiler(TRUE);

	}










}

