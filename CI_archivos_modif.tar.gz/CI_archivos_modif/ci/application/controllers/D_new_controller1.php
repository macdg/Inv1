<?php
//if (!defined('BASEPATH') OR exit('No direct script access allowed')) {;
// }

class D_new_controller1 extends CI_Controller {

//private $datos_del_string=array();

	public function __construct() {
		parent::__construct();
		$this->load->helper('file');

		$this->load->helper('directory');

	}

	public function index() {

		//form_upload('', $mi_file);
		// echo base_url();
		// echo '<br><br>';
		// echo uri_string();
		// echo '<br>'.'<br>';
		// echo current_url();
		// echo '<br><br>';

		//$cadena['mdata'] = array(get_filenames('/root/CertificadosUnion/'));

		//ESTO ME MARCA ERROR SIEMPRE Y CUANDO NO DESCOMENTE LO DE ABAJO
		//$cadena = get_filenames('/root/CertificadosUnion/');

		//$this->load->view('d_new_view', $cadena, TRUE);

		//$this->load->view('d_new_view', $cadena);

		// $c_hay = count($cadena);
		// echo '<br>Lo que hay:'.$c_hay;

		//$this->load->view('d_new_view', $c_hay);

		//ESTA ES LA ULTIMA CADENA Q NO M MARCABA ERROR, TIENE Q VER CON LO COMENTADO D ARRIBA.
		//		$this->load->view('d_new_view');

		// foreach ($cadena as $c_hay => $value) {
		// 	echo '<br>'."La Cadena:".$c_hay.' Valores:'.$value.'<br>';
		// 	// $this->load->view('d_new_view', $c_hay);
		// 	// $this->load->view('d_new_view', $value);
		// }
		// $this->load->view('d_new_view', $cadena);
		// $this->load->view('d_new_view', $value);
		// $this->load->view('d_new_view', $c_hay);
		// $this->load->view('d_new_view', $value);

		// $this->load->view('d_new_view', $c_hay);

		// foreach ($cadena as $col) {
		// 	echo "<br>".$cadena['carpeta'].$col;
		// }
		// echo "<br>";

		//$kk = array(print_r($cadena));
		// print_r($cadena);
		// for ($i = 0; $i != NULL; $i++) {
		// 	echo 'Esta es:'.$cadena[i];
		// 	echo '<br>';
		// 	$this->load->view('d_new_view', $cadena[i]);

		// }

		// echo '<br><br>';
		// echo "<pre>";
		// print_r($cadena);
		// echo "</pre>";

		//$this->load->view('d_new_view', $cadena);
		// foreach ($cadena as $ak => $v) {
		// 	echo "Numero:".$ak.' Valor:'.$v;
		// 	echo "<br>";
		//}
		//echo read_file('/root/CertificadosUnion/');
		echo '<br>';
		echo '--------------------'.'<br>';
		//get_filenames('/root/CertificadosUnion/', TRUE);
		//echo '<br>';
		//Este es el valor del array que imprime todos los archivos.
		//$cadena = array(get_filenames('/root/CertificadosUnion/'));
		//echo '<br>';
		//Este var_dump me muestra realmente el contenido de la carpeta pero no me deja imprimirlos en la vista.
		//var_dump($cadena);
		//echo '<br>';
		//$this->load->view('d_new_view', $cadena);
		//$micadena = $this->load->view('d_new_view', $cadena, '', FALSE);
		//$this->input->post('algun_dato');
		//$this->input->server('algun_dato');

		// MANEJANDO LOS ARCHIVOS
		$ruta_archivo = '/root/CertificadosUnion1/';
		$nom_archivo  = 'archivo.php';
		$espacio      = ''.'                                               --------------------- ';
		$datos        = $espacio.'Inicio de Cadena, esto es lo que tiene el archivo "cliente36Pba1.conf"      '.PHP_EOL;
		if (!write_file('/root/CertificadosUnion1/archivo.php', $datos)) {
			echo 'No se pudo escribir el archivo';
		} else {
			echo 'Archivo escrito!';
		}

		if (file_exists($ruta_archivo.$nom_archivo)) {
			echo '<br>'."El archivo: ".$nom_archivo.',si existe.';
		} else {
			echo '<br>'.'El archivo: '.$nom_archivo.' ,no existe';
		}

		echo '<br>'.'<br>';

		readfile($ruta_archivo.$nom_archivo);
		echo '<br>'.'<br>';
		$filesize_x = filesize($ruta_archivo.$nom_archivo);
		echo '<br>'.$filesize_x.' bytes <br>';

		$cerrando = fopen($ruta_archivo.$nom_archivo, "r");
		echo '<br>Archivo Abierto';
		////////////////////////////////////////////////////////////////////
		$encab_sock = file_get_contents('/root/CertificadosUnion1/cliente36Pba1.conf', FILE_USE_INCLUDE_PATH);
		write_file($ruta_archivo.$nom_archivo, $encab_sock, 'a+');
		$espacio = ''.'                                               --------------------- ';
		write_file($ruta_archivo.$nom_archivo, $espacio, 'a+');

		//		$this->load->view('d_new_view', $encab_sock);

		///////////////////////////////////////////////////////
		$datos2          = 'Segunda Cadena, esto es lo que tiene el archivo "caPba1.crt"      '.PHP_EOL;
		$string_fichero1 = file_get_contents('/root/CertificadosUnion1/caPba1.crt', FILE_USE_INCLUDE_PATH);
		write_file($ruta_archivo.$nom_archivo, $datos2, 'a+');
		write_file($ruta_archivo.$nom_archivo, $string_fichero1, 'a+');
		$espacio = ''.'                                               --------------------- ';
		write_file($ruta_archivo.$nom_archivo, $espacio, 'a+');

		//		$this->load->view('d_new_view', $string_fichero1);
		////////////////////////////////////////////////////////

		$datos3          = 'Tercer Cadena, esto es lo que tiene el archivo "CertificadoCERT.cert"      '.PHP_EOL;
		$string_fichero2 = file_get_contents('/root/CertificadosUnion1/CertificadoCERT.cert', FILE_USE_INCLUDE_PATH);
		write_file($ruta_archivo.$nom_archivo, $datos3, 'a+');
		write_file($ruta_archivo.$nom_archivo, $string_fichero2, 'a+');
		$espacio = ''.'                                               --------------------- ';
		write_file($ruta_archivo.$nom_archivo, $espacio, 'a+');

		//		$this->load->view('d_new_view', $string_fichero2);
		//////////////////////////////////////////////////////
		$datos4 = 'Cuarta Cadena, esto es lo que tiene el archivo "cliente27Pba1.key"      '.PHP_EOL;
		write_file($ruta_archivo.$nom_archivo, $datos4, 'a+');
		$string_fichero3 = file_get_contents('/root/CertificadosUnion1/cliente27Pba1.key', FILE_USE_INCLUDE_PATH);
		write_file($ruta_archivo.$nom_archivo, $string_fichero3, 'a+');

		$espacio = ''.'                                               ----------------------';
		write_file($ruta_archivo.$nom_archivo, $espacio, 'a+');
		$array                    = array();
		$array['encab_sock']      = $encab_sock;
		$array['string_fichero1'] = $string_fichero1;
		$array['string_fichero2'] = $string_fichero2;
		$array['string_fichero3'] = $string_fichero3;
		// /**/
		$array['nom_archivo'] = $nom_archivo;
		/**/
		$this->load->view('d_new_view1', $array);

?>
<hr><br>
SEPARACION PARA VER Q CONTIENEN LAS VARIABLES
<hr><br>
<?php

// echo '$encab_sock:  '.var_dump($encab_sock).'<br>';
// echo '$string_fichero1:  '.var_dump($string_fichero1).'<br>';
// echo '$string_fichero2:  '.var_dump($string_fichero2).'<br>';
// echo '$string_fichero3:  '.var_dump($string_fichero3).'<br>';
// $datos_del_string=array();
// $datos_del_string['i']=$encab_sock;
// $datos_del_string['j']=$string_fichero1;
// $datos_del_string['k']=$string_fichero2;
// $datos_del_string['l']=$string_fichero3;
//echo '<br>'.'$string_fichero3:  '.var_dump($string_fichero3).'<br>';

//$this->load->view('d_new_view1', $datos_del_string);


// echo '$datos_del_string[]:  '.var_dump($datos_del_string['i']).'<br>';
// var_dump($datos_del_string);

// print_r($datos_del_string);


		// $CI->load->view('d_new_view', $encab_sock, $string_fichero1, $string_fichero2, $string_fichero3);

		//$var_readfile_x = readfile($ruta_archivo.$nom_archivo);
		//Aqui me va a faltar la otra parte de la cadena.

		fclose($cerrando);
		echo '<br>Archivo Cerrado';

		// $this->load->view('d_new_view', compact('encab_sock', 'string_fichero1', 'string_fichero2', 'string_fichero3'));

		// $info2=get_dir_file_info('root/CertificadosUnion1/',TRUE);
		// $this->load->view('d_new_view',$info2);
		// echo '<br><br>';
		//$info_carpeta=array(get_file_info('/root/CertificadosUnion1/archivo.php'));
		// echo '<br>';
		// //print_r($info_carpeta);
		//$this->load->view('d_new_view',$info_carpeta);
		echo '<br>';
		// print_r($file_information);
		// echo $file_information;
		echo '<br>';
		//var_dump($info_carpeta);
		//var_dump($file_information);
		$this->output->enable_profiler(TRUE);

	}

	// public function index1() {
	// MANEJANDO LOS ARCHIVOS

	// $gatos = 'Algunos datos de archivo';
	// write_file('/root/CertificadosUnion1/archivo.php', $gatos, 'r+');
	// if ( ! write_file('/root/CertificadosUnion1/archivo.php', $gatos))
	// 	{
	//     echo 'No se pudo escribir el archivo';
	// 	}
	// else
	// {
	//     echo 'Archivo escrito!';
	// }

	// }

}

