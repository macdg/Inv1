
<?php
if (!defined('BASEPATH') exit('No direct script access allowed')) {;
}

class Firma_c extends CI_Controller {

	function index() {
		$datos['titulo']    = 'Upload de Archivos';
		$datos['contenido'] = 'firmav';
		$this->load->view('firmav', $datos);}

	function do_upload() {
		$config['upload_path']   = '/var/www/ci/uploads/';
		$config['allowed_types'] = 'crt|ovpn|key';
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload()) {
			echo "<Error 123> No puede subir los datos.";
			//$config['error']    = $this->upload->display_errors();
			// 	$datos['titulo']    = 'Upload de Archivos';
			// 	$datos['contenido'] = 'firmav';
			// 	$this->load->view('firmav', $datos);
		} else {
			$config['success']  = $this->upload->data();
			$datos['titulo']    = 'Carga Exitosa';
			$datos['contenido'] = 'firmav';
			$this->load->view('upload_sucessv', $datos);

		}
	}

	/*function __construct() {
parent::__construct();
}

function index() {

$this->load->view('firmav');

// 	<form method="post" action="accion.php" enctype="multipart/form-data">

// 	Ingresa el archivo:

// 	<input name="imagen" type="file" />

// </form>

}*/

}
?>