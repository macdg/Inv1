<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-20 17:00:18 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 243
ERROR - 2015-08-20 17:17:04 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/ci/application/views/up_xml_view.php 292
ERROR - 2015-08-20 17:22:20 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/Up_xml_controller.php 166
ERROR - 2015-08-20 17:40:42 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 93
ERROR - 2015-08-20 17:47:25 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/ci/application/views/up_xml_view.php 90
ERROR - 2015-08-20 21:10:14 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-20 21:12:51 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/controllers/Up_xml_controller.php 173
