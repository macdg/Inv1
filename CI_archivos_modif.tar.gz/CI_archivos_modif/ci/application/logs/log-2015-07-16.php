<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-16 11:16:39 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' /var/www/ci/application/views/firmav.php 11
ERROR - 2015-07-16 11:16:42 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' /var/www/ci/application/views/firmav.php 11
ERROR - 2015-07-16 09:43:24 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-16 09:43:24 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-16 09:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-16 09:48:49 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 09:50:30 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/ci/system/core/Common.php 105
ERROR - 2015-07-16 09:54:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-16 09:54:38 --> Severity: Notice --> Undefined variable: mdata /var/www/ci/application/views/d_new_view.php 26
ERROR - 2015-07-16 09:54:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 26
ERROR - 2015-07-16 09:55:02 --> Severity: Notice --> Undefined variable: mdata /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-16 09:55:02 --> Severity: Notice --> Undefined variable: mdata /var/www/ci/application/views/d_new_view.php 26
ERROR - 2015-07-16 09:55:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 26
ERROR - 2015-07-16 09:57:32 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 09:57:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 28
ERROR - 2015-07-16 09:59:59 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 09:59:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 29
ERROR - 2015-07-16 10:05:45 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 10:05:45 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 30
ERROR - 2015-07-16 10:13:18 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 10:13:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 30
ERROR - 2015-07-16 10:13:18 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:13:18 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 10:13:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 30
ERROR - 2015-07-16 10:13:18 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 29
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 27
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 29
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:14:17 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:16:46 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:18:26 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:19:52 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:31:46 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:41:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 10:48:18 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 13:46:53 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 13:47:27 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:14:13 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:16:44 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:19:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:19:36 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:19:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:19:36 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 19
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:19:50 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 37
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 42
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:25:12 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 42
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 42
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Array to string conversion /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 36
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:25:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 42
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:26:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 16:26:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 39
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 40
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:26:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 16:26:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 39
ERROR - 2015-07-16 16:26:31 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 40
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:28:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:28:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 46
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 47
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:28:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:28:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 46
ERROR - 2015-07-16 16:28:09 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 47
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 46
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 47
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 46
ERROR - 2015-07-16 16:29:34 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 47
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 46
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 47
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 41
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 46
ERROR - 2015-07-16 16:37:21 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 47
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:40:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:41:02 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:41:41 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 58
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 63
ERROR - 2015-07-16 16:42:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:43:41 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:43:56 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:43:57 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 59
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 64
ERROR - 2015-07-16 16:44:41 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 71
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 16:48:13 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 71
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 71
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 16:48:22 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 71
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 71
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 65
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 16:55:07 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 71
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:27:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:27:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:27:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:27:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-16 17:27:25 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-16 17:28:19 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-16 18:31:40 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 18:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-16 18:31:40 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 18:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-16 18:31:40 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-16 18:31:40 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
