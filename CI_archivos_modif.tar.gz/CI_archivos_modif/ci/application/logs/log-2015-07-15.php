<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-15 11:16:26 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:16:39 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:16:49 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:16:52 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:17:04 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:18:10 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:21:49 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:21:52 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:21:55 --> Unable to load the requested class: Form
ERROR - 2015-07-15 11:30:30 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:31:07 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:31:41 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:32:03 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:32:17 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:32:19 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:32:44 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/ci/application/config/routes.php 52
ERROR - 2015-07-15 11:32:50 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/ci/application/config/routes.php 52
ERROR - 2015-07-15 11:32:53 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/ci/application/config/routes.php 52
ERROR - 2015-07-15 11:33:21 --> Severity: Parsing Error --> syntax error, unexpected ''files'' (T_CONSTANT_ENCAPSED_STRING) /var/www/ci/application/config/routes.php 52
ERROR - 2015-07-15 11:33:46 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:33:48 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:33:50 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:34:20 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:34:25 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:34:31 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:34:53 --> Severity: Notice --> Undefined variable: error /var/www/ci/application/views/firmav.php 9
ERROR - 2015-07-15 11:35:24 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 11:35:35 --> Severity: Notice --> Undefined variable: error /var/www/ci/application/views/firmav.php 9
ERROR - 2015-07-15 12:49:10 --> Severity: Error --> Call to undefined method CI_Controller::Controller() /var/www/ci/application/controllers/Firma_c.php 5
ERROR - 2015-07-15 12:52:42 --> Severity: Error --> Call to undefined method CI_Controller::controller() /var/www/ci/application/controllers/Firma_c.php 5
ERROR - 2015-07-15 13:03:07 --> Severity: Error --> Call to undefined method CI_Controller::Controller() /var/www/ci/application/controllers/Firma_c.php 5
ERROR - 2015-07-15 13:25:26 --> Severity: Parsing Error --> syntax error, unexpected ''Jijijijii'' (T_CONSTANT_ENCAPSED_STRING) /var/www/ci/application/controllers/Firma_c.php 26
ERROR - 2015-07-15 13:45:32 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:47:00 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:47:01 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:47:01 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:47:45 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:47:47 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:54:00 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 13:56:59 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 14:01:09 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 14:02:54 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 14:03:44 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 15:00:32 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:01:03 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:01:04 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:01:09 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:01:14 --> 404 Page Not Found: Welcome/files/uploads
ERROR - 2015-07-15 15:01:22 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:01:37 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:01:44 --> 404 Page Not Found: Welcome/files/uploads
ERROR - 2015-07-15 15:02:01 --> 404 Page Not Found: /index
ERROR - 2015-07-15 15:02:02 --> 404 Page Not Found: /index
ERROR - 2015-07-15 15:02:05 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:02:06 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:02:08 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:02:15 --> 404 Page Not Found: Upload/index.php
ERROR - 2015-07-15 15:02:19 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:04:39 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'trabajando' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 15:04:42 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'trabajando' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 15:05:04 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'trabajando' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 15:05:05 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'trabajando' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 15:05:34 --> 404 Page Not Found: /index
ERROR - 2015-07-15 15:05:41 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:06:03 --> 404 Page Not Found: Upload/formulario_carg
ERROR - 2015-07-15 15:06:35 --> 404 Page Not Found: Upload/formulario_carga
ERROR - 2015-07-15 15:06:49 --> 404 Page Not Found: Upload/formulario_carga
ERROR - 2015-07-15 15:06:57 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:07:29 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:07:44 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:07:48 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:07:58 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:09:55 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:09:56 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:10:05 --> 404 Page Not Found: Upload/index
ERROR - 2015-07-15 15:11:30 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'trabajando' /var/www/ci/system/core/CodeIgniter.php 514
ERROR - 2015-07-15 15:55:03 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/ci/application/controllers/Firma_c.php 16
ERROR - 2015-07-15 16:49:42 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/ci/application/controllers/Firma_c.php 16
ERROR - 2015-07-15 16:50:01 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/ci/application/controllers/Firma_c.php 16
ERROR - 2015-07-15 16:50:02 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/ci/application/controllers/Firma_c.php 16
ERROR - 2015-07-15 16:50:04 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/ci/application/controllers/Firma_c.php 16
ERROR - 2015-07-15 16:50:52 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/ci/application/controllers/Firma_c.php 31
ERROR - 2015-07-15 16:54:35 --> Severity: Notice --> Undefined variable: success /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 16:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 17:01:07 --> Severity: Notice --> Undefined variable: error /var/www/ci/application/views/formulario_carga.php 6
ERROR - 2015-07-15 17:01:08 --> Severity: Notice --> Undefined variable: error /var/www/ci/application/views/formulario_carga.php 6
ERROR - 2015-07-15 17:01:10 --> Severity: Notice --> Undefined variable: error /var/www/ci/application/views/formulario_carga.php 6
ERROR - 2015-07-15 17:01:56 --> Severity: Error --> Call to undefined method CI_Controller::Controller() /var/www/ci/application/controllers/Upload.php 5
ERROR - 2015-07-15 17:04:54 --> Severity: Error --> Call to undefined method CI_Controller::Controller() /var/www/ci/application/controllers/Upload.php 5
ERROR - 2015-07-15 17:09:12 --> Severity: Error --> Call to undefined method CI_Controller::Controller() /var/www/ci/application/controllers/Upload.php 5
ERROR - 2015-07-15 17:09:34 --> Severity: Error --> Call to undefined method CI_Controller::Controller() /var/www/ci/application/controllers/Upload.php 5
ERROR - 2015-07-15 17:16:12 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:17:06 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:18:36 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:22:11 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:25:01 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:25:24 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:27:40 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:27:55 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:30:39 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:31:19 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:33:38 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:35:57 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:36:04 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:36:35 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:36:42 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:36:48 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:36:56 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:39:56 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 17:40:25 --> The upload path does not appear to be valid.
ERROR - 2015-07-15 18:19:10 --> Severity: Notice --> Undefined variable: success /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:19:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:24:05 --> Severity: Notice --> Undefined variable: success /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:24:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:24:23 --> Severity: Notice --> Undefined variable: su /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:41:31 --> Severity: Notice --> Undefined variable: su /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:41:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:42:55 --> Severity: Notice --> Undefined variable: config /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:43:18 --> Severity: Notice --> Use of undefined constant success - assumed 'success' /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:43:35 --> Severity: Notice --> Undefined variable: success /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:43:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:44:16 --> Severity: Notice --> Undefined variable: config /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:44:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:44:52 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:45:36 --> Severity: Notice --> Undefined variable: config /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:45:36 --> Severity: Notice --> Undefined variable: success /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:45:36 --> Severity: Notice --> Trying to get property of non-object /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:46:09 --> Severity: Notice --> Undefined variable: item /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:46:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:48:10 --> Severity: Notice --> Undefined variable: success /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:48:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/upload_sucessv.php 4
ERROR - 2015-07-15 18:09:10 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '{' /var/www/ci/application/controllers/D_new_controller.php 2
ERROR - 2015-07-15 18:09:58 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '{' /var/www/ci/application/controllers/D_new_controller.php 2
ERROR - 2015-07-15 18:10:27 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/ci/application/views/d_new_view.php 4
ERROR - 2015-07-15 18:11:07 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/ci/application/views/d_new_view.php 4
ERROR - 2015-07-15 18:11:34 --> Severity: Parsing Error --> syntax error, unexpected 'archivo' (T_STRING), expecting ',' or ';' /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 18:13:58 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/ci/application/views/d_new_view.php 12
ERROR - 2015-07-15 18:14:26 --> Severity: Notice --> Undefined variable: nom_arch /var/www/ci/application/views/d_new_view.php 8
ERROR - 2015-07-15 18:15:34 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/ci/application/views/d_new_view.php 12
ERROR - 2015-07-15 19:28:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:29:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:30:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:30:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:31:48 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:31:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:34 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:49 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:51 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:33:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:34:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:34:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:36:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:37:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:37:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:37:56 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:37:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:38:37 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:39:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:40:36 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 18
ERROR - 2015-07-15 19:40:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:40:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:40:39 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 18
ERROR - 2015-07-15 19:40:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:40:40 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 18
ERROR - 2015-07-15 19:40:40 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:40:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:41:54 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 18
ERROR - 2015-07-15 19:41:54 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:41:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:41:55 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 18
ERROR - 2015-07-15 19:41:55 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:41:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:43:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:43:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:43:41 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:43:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:43:42 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:43:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:27 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:28 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:28 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:29 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:45:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:45:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:45:48 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:46:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:46:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:46:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:51:26 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/ci/application/controllers/D_new_controller.php 20
ERROR - 2015-07-15 19:53:37 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:53:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 19:57:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 12
ERROR - 2015-07-15 19:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 12
ERROR - 2015-07-15 19:59:26 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/ci/application/views/d_new_view.php 15
ERROR - 2015-07-15 19:59:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 12
ERROR - 2015-07-15 19:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 12
ERROR - 2015-07-15 20:00:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:01:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:02:28 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:03:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:03:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:03:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:04:29 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:05:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:05:26 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:05:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:06:01 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:06:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 11
ERROR - 2015-07-15 20:09:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-15 20:09:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:09:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:10:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 21
ERROR - 2015-07-15 20:10:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:11:02 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:11:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:11:55 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:12:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:16:43 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:22:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:22:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:23:11 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:23:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:24:46 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:24:46 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-15 20:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-15 20:25:31 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:25:31 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-15 20:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-15 20:26:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 23
ERROR - 2015-07-15 20:26:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 25
ERROR - 2015-07-15 20:26:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 25
