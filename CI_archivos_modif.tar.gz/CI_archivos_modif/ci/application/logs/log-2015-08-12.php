<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-12 13:43:31 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-12 13:43:31 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-12 13:43:31 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-12 13:44:11 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view1.php 20
ERROR - 2015-08-12 13:44:11 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-12 13:44:11 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-12 13:51:54 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-12 13:51:54 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-12 13:51:54 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-12 14:13:59 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /var/www/ci/application/controllers/Inv_c.php 22
ERROR - 2015-08-12 14:14:14 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/ci/application/controllers/Inv_c.php 23
ERROR - 2015-08-12 14:14:35 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:15:18 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:16:46 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:16:47 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:16:48 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:16:50 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:17:27 --> Severity: Warning --> Illegal string offset '$array' /var/www/ci/application/controllers/Inv_c.php 20
ERROR - 2015-08-12 14:17:27 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:20:03 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:20:16 --> Severity: Notice --> Undefined variable: array /var/www/ci/application/views/inv_v.php 17
ERROR - 2015-08-12 14:24:35 --> Severity: Notice --> Undefined variable: tabla_html /var/www/ci/application/controllers/Inv_c.php 21
ERROR - 2015-08-12 14:25:07 --> Severity: Notice --> Undefined variable: tabla_html /var/www/ci/application/controllers/Inv_c.php 21
ERROR - 2015-08-12 14:25:08 --> Severity: Notice --> Undefined variable: tabla_html /var/www/ci/application/controllers/Inv_c.php 21
ERROR - 2015-08-12 14:25:20 --> Severity: Notice --> Undefined variable: tabla_html /var/www/ci/application/controllers/Inv_c.php 21
ERROR - 2015-08-12 14:33:23 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/ci/application/controllers/Inv_c.php 8
ERROR - 2015-08-12 14:51:33 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/ci/application/controllers/Inv_c.php 8
ERROR - 2015-08-12 14:51:35 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/ci/application/controllers/Inv_c.php 8
ERROR - 2015-08-12 14:51:37 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/ci/application/controllers/Inv_c.php 8
ERROR - 2015-08-12 14:52:02 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 14:52:22 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 14:52:22 --> Severity: Notice --> Undefined variable: mi_fila /var/www/ci/application/views/inv_v.php 18
ERROR - 2015-08-12 14:57:02 --> Severity: Notice --> Undefined index: mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 14:57:02 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 14:57:02 --> Severity: Notice --> Undefined variable: mi_fila /var/www/ci/application/views/inv_v.php 18
ERROR - 2015-08-12 14:59:52 --> Severity: Notice --> Undefined index: mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 14:59:52 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 14:59:52 --> Severity: Notice --> Undefined variable: mi_fila /var/www/ci/application/views/inv_v.php 18
ERROR - 2015-08-12 15:00:32 --> Severity: Notice --> Undefined index: mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:00:32 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:00:55 --> Severity: Notice --> Undefined index: mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:00:55 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:27:12 --> Severity: Notice --> Undefined index: mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:27:12 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:28:14 --> Severity: Error --> Function name must be a string /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:31:20 --> Severity: Error --> Function name must be a string /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:31:41 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:31:41 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:31:41 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:31:59 --> Severity: Notice --> Undefined index: $num_mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:31:59 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:34:17 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:34:17 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:34:17 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:34:17 --> Severity: Notice --> Undefined index:  /var/www/ci/application/views/inv_v.php 26
ERROR - 2015-08-12 15:46:40 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:46:40 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 15:46:40 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 15:46:40 --> Severity: Notice --> Undefined index:  /var/www/ci/application/views/inv_v.php 26
ERROR - 2015-08-12 17:06:01 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 17:06:01 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 17:06:01 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:06:01 --> Severity: Notice --> Undefined index:  /var/www/ci/application/views/inv_v.php 26
ERROR - 2015-08-12 17:06:10 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 17:06:10 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 32
ERROR - 2015-08-12 17:06:10 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:06:10 --> Severity: Notice --> Undefined index:  /var/www/ci/application/views/inv_v.php 26
ERROR - 2015-08-12 17:29:53 --> Severity: Parsing Error --> syntax error, unexpected ']' /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:30:13 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:30:13 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:30:13 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:30:37 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:30:37 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:30:37 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:30:37 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:34:38 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:34:38 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:34:38 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:35:59 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:35:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:35:59 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:36:00 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:36:00 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:36:00 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:37:07 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:37:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:37:07 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:37:07 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 17:38:11 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-12 17:38:11 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 17:38:11 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 38
ERROR - 2015-08-12 17:38:11 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 30
ERROR - 2015-08-12 17:38:11 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 17:39:13 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:39:13 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:39:13 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:39:13 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 17:40:33 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:40:33 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:40:33 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:40:33 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/ci/application/views/inv_v.php 33
ERROR - 2015-08-12 17:40:47 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:40:47 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:40:47 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:40:47 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 17:40:47 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 17:42:08 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:42:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:42:08 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:42:08 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 17:42:08 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 17:42:10 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:42:10 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:42:10 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:42:10 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 17:42:10 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 17:43:39 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:43:39 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:43:39 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 17:43:39 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 17:45:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:45:59 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:45:59 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 17:47:21 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:47:21 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:47:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:47:31 --> Severity: Notice --> Undefined variable: tabla_tam /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-12 17:48:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:48:41 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:56:15 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:56:27 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:56:52 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:57:53 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:57:53 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:58:11 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:58:11 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 17:59:20 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 17:59:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 17:59:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 17:59:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:00:30 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:00:30 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:00:30 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:00:30 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:00:31 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:00:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:00:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:00:31 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:00:33 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:00:33 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:00:33 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:00:33 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:00:34 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:00:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:00:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:00:34 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:01:09 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:01:09 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:01:09 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:01:09 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:01:16 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:01:16 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:01:16 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:01:16 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:01:51 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:01:51 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:01:51 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:01:51 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:02:00 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:02:00 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:02:00 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:02:00 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:03:16 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:03:16 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:03:16 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:03:16 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:03:17 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:04:08 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:04:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:04:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:04:08 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:05:47 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:05:47 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:05:47 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:05:47 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:06:18 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:06:18 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 31
ERROR - 2015-08-12 18:06:18 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:06:18 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:06:18 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:09:43 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:09:43 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 31
ERROR - 2015-08-12 18:09:43 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:09:43 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:09:43 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:11:07 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:11:07 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 31
ERROR - 2015-08-12 18:11:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:11:07 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:11:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:11:08 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:11:08 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 31
ERROR - 2015-08-12 18:11:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:11:08 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:11:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:11:39 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:11:39 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:11:39 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:11:39 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:11:39 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:13:13 --> Severity: Compile Error --> Cannot use [] for reading /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:13:45 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:13:45 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 32
ERROR - 2015-08-12 18:13:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:13:45 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:13:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:17:34 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:17:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:17:34 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:17:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:17:35 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:17:35 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:17:35 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:17:35 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:22:43 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:22:43 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:22:43 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:22:43 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:22:44 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:22:44 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:22:44 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:22:44 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:24:05 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:24:05 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:24:05 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:24:05 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:24:05 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:25:11 --> Severity: Notice --> Undefined index: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:25:11 --> Severity: Notice --> Undefined index: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:25:11 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:25:11 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:25:11 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:25:12 --> Severity: Notice --> Undefined index: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:25:12 --> Severity: Notice --> Undefined index: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:25:12 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:25:12 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:25:12 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:25:48 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:25:48 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:25:48 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:25:48 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:25:48 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:25:49 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:25:49 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:25:49 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:25:49 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:25:49 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:26:42 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 34
ERROR - 2015-08-12 18:26:42 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:26:42 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:26:42 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:26:42 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:27:44 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:27:44 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:27:44 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:27:44 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:27:44 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:27:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:30:19 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:30:19 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:30:19 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:30:19 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:30:19 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:30:31 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:30:31 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:30:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:30:31 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 51
ERROR - 2015-08-12 18:30:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 52
ERROR - 2015-08-12 18:35:21 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:35:21 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:35:21 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 48
ERROR - 2015-08-12 18:35:21 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 49
ERROR - 2015-08-12 18:35:21 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 50
ERROR - 2015-08-12 18:37:29 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:37:29 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:37:29 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:37:29 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:37:29 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:37:59 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 35
ERROR - 2015-08-12 18:37:59 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:37:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:37:59 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:37:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:39:13 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:39:13 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:39:13 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 46
ERROR - 2015-08-12 18:39:13 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:39:13 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:39:13 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:40:44 --> Severity: Compile Error --> Cannot use [] for reading /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:40:56 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:40:56 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:40:56 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 46
ERROR - 2015-08-12 18:40:56 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:40:56 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:40:56 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:42:34 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:42:34 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:42:34 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:42:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:42:34 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:42:34 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:42:46 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:42:46 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:42:46 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:42:46 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:42:46 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:42:46 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:43:06 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:43:06 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:43:06 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:43:06 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:43:06 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:43:06 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:43:10 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:43:10 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:43:10 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:43:10 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:43:10 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:43:10 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:43:37 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:43:37 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:43:37 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:43:37 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:43:37 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:43:37 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 27
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:44:02 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 27
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-12 18:44:03 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
