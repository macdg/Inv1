<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-06 12:59:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 25
