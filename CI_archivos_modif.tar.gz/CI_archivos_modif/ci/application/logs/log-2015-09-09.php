<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-09 10:00:34 --> Severity: Error --> Call to undefined method B_up_xml_controller1::compara_cambia() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 229
ERROR - 2015-09-09 10:01:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 247
ERROR - 2015-09-09 10:01:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 247
ERROR - 2015-09-09 10:07:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 247
ERROR - 2015-09-09 10:07:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 247
ERROR - 2015-09-09 10:12:27 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 251
ERROR - 2015-09-09 10:13:35 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 252
ERROR - 2015-09-09 10:15:02 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 252
ERROR - 2015-09-09 10:18:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:18:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:19:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:19:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:19:44 --> Severity: Notice --> Undefined variable: result_arreglado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 259
ERROR - 2015-09-09 10:20:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:20:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:20:24 --> Severity: Notice --> Undefined variable: result_arreglado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 259
ERROR - 2015-09-09 10:21:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:21:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:21:30 --> Severity: Notice --> Undefined variable: result_arreglado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 259
ERROR - 2015-09-09 10:21:30 --> Severity: Notice --> Undefined variable: result_arreglado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 260
ERROR - 2015-09-09 10:34:23 --> Severity: Parsing Error --> syntax error, unexpected ']', expecting ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 257
ERROR - 2015-09-09 10:34:29 --> Severity: Parsing Error --> syntax error, unexpected ']', expecting ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 257
ERROR - 2015-09-09 10:34:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:34:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:34:48 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 264
ERROR - 2015-09-09 10:34:48 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:36:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:36:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:36:14 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 264
ERROR - 2015-09-09 10:36:14 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:36:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:36:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:36:59 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 264
ERROR - 2015-09-09 10:36:59 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:37:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:37:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:37:48 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 264
ERROR - 2015-09-09 10:37:48 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:39:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:39:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:39:24 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:39:24 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-09 10:40:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:40:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:40:09 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:40:09 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-09 10:41:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:41:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:41:21 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:41:21 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-09 10:44:00 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:44:00 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:44:00 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:44:00 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-09 10:45:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:45:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:45:22 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:45:22 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-09 10:46:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:46:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:46:15 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-09 10:46:15 --> Severity: Notice --> Undefined variable: result2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-09 10:46:53 --> Severity: Parsing Error --> syntax error, unexpected 'attr' (T_STRING) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-09 10:47:43 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-09 10:48:09 --> Severity: Parsing Error --> syntax error, unexpected '"["' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-09 10:48:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:48:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:50:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:50:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:51:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 10:51:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 248
ERROR - 2015-09-09 11:05:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 246
ERROR - 2015-09-09 11:05:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 246
ERROR - 2015-09-09 11:05:27 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 11:05:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:05:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:05:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-09 11:06:45 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 11:06:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:06:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:07:07 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:10:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:10:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:11:12 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:12:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:12:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:12:39 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:13:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:13:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:13:35 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:14:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:14:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:15:21 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:30:46 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:30:46 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:31:08 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:31:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:31:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:32:06 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:33:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:33:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:33:51 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:36:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:36:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:36:25 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:38:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:38:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:39:10 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:42:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:42:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:43:11 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:44:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:44:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:44:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:44:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:44:31 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:44:35 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:49:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:49:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:49:48 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:49:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:49:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:50:14 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:50:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:50:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:51:02 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:51:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:51:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:51:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:51:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:51:36 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:51:46 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:52:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:52:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:53:00 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:53:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:53:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:53:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:53:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:54:06 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:56:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:56:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:56:40 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:57:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:57:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:57:33 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 11:58:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-09 11:58:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-09 11:58:50 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133169152 bytes) /var/www/html/ci/application/views/b_xmlcaso1_view.php 117
ERROR - 2015-09-09 12:04:56 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-09 12:04:56 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-09 12:04:56 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 218
ERROR - 2015-09-09 12:04:56 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 237
ERROR - 2015-09-09 12:04:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-09 12:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 292
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 311
ERROR - 2015-09-09 12:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 311
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-09 12:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 12:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 365
ERROR - 2015-09-09 12:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 365
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 379
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 380
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 381
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 383
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 384
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 387
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: calle /var/www/html/ci/application/controllers/B_up_xml_controller1.php 388
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: no_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 389
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: no_int /var/www/html/ci/application/controllers/B_up_xml_controller1.php 390
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: colonia /var/www/html/ci/application/controllers/B_up_xml_controller1.php 391
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: referen /var/www/html/ci/application/controllers/B_up_xml_controller1.php 392
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: mun /var/www/html/ci/application/controllers/B_up_xml_controller1.php 393
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: estado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 394
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: pais /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: cp /var/www/html/ci/application/controllers/B_up_xml_controller1.php 396
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 400
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: fecha /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: subtotal /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: moneda /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-09 12:06:38 --> Severity: Notice --> Undefined variable: total /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-09 12:07:44 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 293
ERROR - 2015-09-09 12:08:31 --> Severity: Parsing Error --> syntax error, unexpected 'cantidad' (T_STRING), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 295
ERROR - 2015-09-09 12:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 292
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 311
ERROR - 2015-09-09 12:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 311
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-09 12:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 12:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 365
ERROR - 2015-09-09 12:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 365
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 379
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 380
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 381
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 383
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 384
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 387
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: calle /var/www/html/ci/application/controllers/B_up_xml_controller1.php 388
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: no_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 389
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: no_int /var/www/html/ci/application/controllers/B_up_xml_controller1.php 390
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: colonia /var/www/html/ci/application/controllers/B_up_xml_controller1.php 391
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: referen /var/www/html/ci/application/controllers/B_up_xml_controller1.php 392
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: mun /var/www/html/ci/application/controllers/B_up_xml_controller1.php 393
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: estado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 394
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: pais /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: cp /var/www/html/ci/application/controllers/B_up_xml_controller1.php 396
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 400
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: fecha /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: subtotal /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: moneda /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-09 12:09:15 --> Severity: Notice --> Undefined variable: total /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-09 12:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 292
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 311
ERROR - 2015-09-09 12:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 311
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-09 12:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 12:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 365
ERROR - 2015-09-09 12:09:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 365
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 379
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 380
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 381
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 383
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 384
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 387
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: calle /var/www/html/ci/application/controllers/B_up_xml_controller1.php 388
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: no_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 389
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: no_int /var/www/html/ci/application/controllers/B_up_xml_controller1.php 390
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: colonia /var/www/html/ci/application/controllers/B_up_xml_controller1.php 391
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: referen /var/www/html/ci/application/controllers/B_up_xml_controller1.php 392
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: mun /var/www/html/ci/application/controllers/B_up_xml_controller1.php 393
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: estado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 394
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: pais /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: cp /var/www/html/ci/application/controllers/B_up_xml_controller1.php 396
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 400
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: fecha /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: subtotal /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: moneda /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-09 12:09:59 --> Severity: Notice --> Undefined variable: total /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-09 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 317
ERROR - 2015-09-09 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 317
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-09 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-09 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 371
ERROR - 2015-09-09 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 371
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 385
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 386
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 387
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 388
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 389
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 390
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 393
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: calle /var/www/html/ci/application/controllers/B_up_xml_controller1.php 394
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: no_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: no_int /var/www/html/ci/application/controllers/B_up_xml_controller1.php 396
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: colonia /var/www/html/ci/application/controllers/B_up_xml_controller1.php 397
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: referen /var/www/html/ci/application/controllers/B_up_xml_controller1.php 398
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: mun /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: estado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 400
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: pais /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: cp /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: fecha /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: subtotal /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: moneda /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 12:11:09 --> Severity: Notice --> Undefined variable: total /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 12:15:51 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 278
ERROR - 2015-09-09 12:16:16 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 278
ERROR - 2015-09-09 12:17:11 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 278
ERROR - 2015-09-09 12:17:21 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller1.php 281
ERROR - 2015-09-09 12:17:34 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 283
ERROR - 2015-09-09 12:17:51 --> Severity: Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-09 12:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 317
ERROR - 2015-09-09 12:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 317
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-09 12:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-09 12:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 371
ERROR - 2015-09-09 12:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 371
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 385
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 386
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 387
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 388
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 389
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 390
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 393
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: calle /var/www/html/ci/application/controllers/B_up_xml_controller1.php 394
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: no_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: no_int /var/www/html/ci/application/controllers/B_up_xml_controller1.php 396
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: colonia /var/www/html/ci/application/controllers/B_up_xml_controller1.php 397
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: referen /var/www/html/ci/application/controllers/B_up_xml_controller1.php 398
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: mun /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: estado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 400
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: pais /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: cp /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: fecha /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: subtotal /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: moneda /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 12:18:11 --> Severity: Notice --> Undefined variable: total /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 12:20:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:20:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 298
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 385
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 386
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 387
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 388
ERROR - 2015-09-09 12:22:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 389
ERROR - 2015-09-09 12:34:16 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 491
ERROR - 2015-09-09 12:36:21 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 491
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 310
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 312
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 445
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 446
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 447
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-09 12:37:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-09 12:45:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 310
ERROR - 2015-09-09 12:45:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 312
ERROR - 2015-09-09 12:47:02 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:47:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:47:02 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-09 12:47:02 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 455
ERROR - 2015-09-09 12:47:02 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-09 12:47:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-09 12:47:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-09 12:49:21 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:49:21 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-09 12:49:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 455
ERROR - 2015-09-09 12:49:21 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-09 12:49:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-09 12:49:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-09 12:52:51 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:52:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:52:51 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-09 12:52:51 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-09 12:52:51 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-09 12:52:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-09 12:52:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-09 12:55:46 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:55:46 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 541
ERROR - 2015-09-09 12:55:46 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 542
ERROR - 2015-09-09 12:55:46 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 543
ERROR - 2015-09-09 12:55:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 544
ERROR - 2015-09-09 12:55:46 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 12:57:09 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:57:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 12:57:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 541
ERROR - 2015-09-09 12:57:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 542
ERROR - 2015-09-09 12:57:09 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 543
ERROR - 2015-09-09 12:57:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 544
ERROR - 2015-09-09 12:57:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:00:56 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:00:56 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 541
ERROR - 2015-09-09 13:00:56 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 542
ERROR - 2015-09-09 13:00:56 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 543
ERROR - 2015-09-09 13:00:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 544
ERROR - 2015-09-09 13:00:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:06:23 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:06:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:06:23 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 541
ERROR - 2015-09-09 13:06:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 542
ERROR - 2015-09-09 13:06:23 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 543
ERROR - 2015-09-09 13:06:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 544
ERROR - 2015-09-09 13:06:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:06:35 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:06:35 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 541
ERROR - 2015-09-09 13:06:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 542
ERROR - 2015-09-09 13:06:35 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 543
ERROR - 2015-09-09 13:06:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 544
ERROR - 2015-09-09 13:06:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:08:45 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:08:45 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 544
ERROR - 2015-09-09 13:10:47 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:10:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:12:31 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:12:31 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:13:48 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:13:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:13:48 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 545
ERROR - 2015-09-09 13:13:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 13:13:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 13:13:58 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 13:13:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 382
ERROR - 2015-09-09 13:21:28 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 480
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 329
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-09 13:23:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 13:23:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:23:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:24:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:24:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:24:44 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:24:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 514
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:37:05 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 566
ERROR - 2015-09-09 13:40:37 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 398
ERROR - 2015-09-09 13:40:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 398
ERROR - 2015-09-09 13:40:37 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 398
ERROR - 2015-09-09 13:40:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 398
ERROR - 2015-09-09 13:40:37 --> Severity: Notice --> Undefined variable: datos_concepto1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 425
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:40:47 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:48:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:48:04 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 13:58:19 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:58:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:58:19 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 13:58:19 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 13:58:19 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 13:58:19 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 13:58:19 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 13:59:44 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 13:59:44 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 13:59:44 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 13:59:44 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 13:59:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 13:59:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:01:35 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:01:35 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:01:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:01:35 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:01:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:01:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:02:33 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:02:33 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:02:33 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:02:33 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:02:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:02:33 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:03:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:04:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: datos_concepto1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 425
ERROR - 2015-09-09 14:04:51 --> Severity: Notice --> Undefined variable: datos_concepto1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 427
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:05:52 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:06:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:06:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 356
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:09:40 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:19:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:19:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:21:14 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:23:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:23:09 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:23:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 425
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 427
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 431
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 433
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 14:24:19 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 439
ERROR - 2015-09-09 14:32:43 --> Severity: Parsing Error --> syntax error, unexpected '$', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 484
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:33:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:33:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:33:11 --> Severity: Notice --> Undefined variable: Array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:37:04 --> Severity: Notice --> Undefined variable: Array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:39:11 --> Severity: Notice --> Undefined variable: Array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 425
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 427
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 431
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 433
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 439
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable:  /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_conceptos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 625
ERROR - 2015-09-09 14:40:42 --> Severity: Notice --> Undefined variable: datos_conceptos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 627
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: Array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: datos_conceptos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 625
ERROR - 2015-09-09 14:42:59 --> Severity: Notice --> Undefined variable: datos_conceptos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 627
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:46:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 351
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:46:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: Array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: datos_conceptos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 625
ERROR - 2015-09-09 14:46:21 --> Severity: Notice --> Undefined variable: datos_conceptos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 627
ERROR - 2015-09-09 15:21:57 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 659
ERROR - 2015-09-09 15:24:21 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 659
ERROR - 2015-09-09 15:25:01 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 659
ERROR - 2015-09-09 15:26:44 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-09 15:28:14 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 659
ERROR - 2015-09-09 15:29:14 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 664
ERROR - 2015-09-09 15:30:01 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 660
ERROR - 2015-09-09 15:30:29 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-09 15:31:03 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 660
ERROR - 2015-09-09 15:31:25 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 664
ERROR - 2015-09-09 15:33:00 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 664
ERROR - 2015-09-09 15:33:03 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 664
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:35:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:35:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:35:47 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:36:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:36:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:36:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:36:35 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:37:05 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:37:13 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:42:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:42:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:42:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:42:21 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 50
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:46:31 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 50
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:46:46 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:49:15 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso1_view.php 46
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 46
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:49:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:49:50 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 46
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:14 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 46
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:51:33 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:53:02 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 15:54:59 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 667
ERROR - 2015-09-09 15:55:29 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 667
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:55:29 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined variable: contador /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:56:44 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 15:58:48 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 667
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 15:58:48 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 667
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 15:58:57 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:00:21 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 667
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:00:21 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:01:29 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:02:36 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:06:59 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:06:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:06:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:06:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:06:59 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:07:40 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:07:40 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:09:19 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:11:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:12:33 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:13:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:13:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:13:38 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:14:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:16:05 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:17:22 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:21:40 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:22:25 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:22:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:23:21 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:23:21 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:23:54 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:23:54 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:25:15 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:15 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:25:45 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:25:45 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:26:28 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:26:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:31:27 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:31:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:33:05 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:33:05 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:33:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:34:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:34:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:34:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Missing argument 5 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Missing argument 6 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Missing argument 7 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Missing argument 8 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:38:43 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:38:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-09 16:38:43 --> Severity: Error --> Call to undefined method B_up_xml_controller1::xx() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Missing argument 5 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Missing argument 6 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Missing argument 7 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Missing argument 8 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:01 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:40:01 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Missing argument 5 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Missing argument 6 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Missing argument 7 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Missing argument 8 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-09 16:40:58 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:40:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Missing argument 5 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Missing argument 6 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Missing argument 7 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Missing argument 8 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:41:42 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:41:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Missing argument 5 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Missing argument 6 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Missing argument 7 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Missing argument 8 for B_up_xml_controller1::x_x(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 459 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:43:13 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:43:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:47:40 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:47:40 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 653
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:47:40 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:48:09 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:09 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 653
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:48:09 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:48:27 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:48:27 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 653
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:48:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:51:25 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 628
ERROR - 2015-09-09 16:51:25 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 653
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:51:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:51:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 16:51:58 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/views/b_xmlcaso1_view.php 51
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 511
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 512
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 513
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 498
ERROR - 2015-09-09 16:51:58 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 653
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-09 16:51:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-09 17:09:25 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:09:25 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:09:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:09:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:09:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:14:00 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:14:00 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:14:00 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:14:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:14:00 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:15:34 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:15:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:15:34 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:15:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:15:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:16:37 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:16:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:16:37 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:16:37 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:16:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:16:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:18:33 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:18:33 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:18:33 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:18:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:18:33 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:20:34 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:20:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:20:34 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:20:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:20:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:21:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:21:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:21:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:21:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:21:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:21:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:23:34 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-09 17:23:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-09 17:23:34 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-09 17:23:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-09 17:23:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-09 17:25:03 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/b_xmlcaso1_view.php 162
ERROR - 2015-09-09 17:52:25 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 648
ERROR - 2015-09-09 17:52:51 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 696
ERROR - 2015-09-09 17:56:04 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 17:56:39 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:05:18 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:08:16 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:09:46 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:11:12 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:12:18 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:13:35 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:14:54 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:15:38 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:17:57 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:18:45 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:19:33 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:21:05 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:21:34 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:24:30 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:25:28 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:25:45 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:26:21 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:26:31 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:27:57 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:28:10 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:29:19 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:30:25 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:32:38 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:34:47 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:41:59 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:43:48 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:44:36 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:44:43 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:46:27 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:46:42 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 18:49:05 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', 'd', NULL)
ERROR - 2015-09-09 18:49:27 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:58:41 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:59:04 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 18:59:49 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:00:10 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:00:38 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:01:08 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:02:31 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:03:15 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:04:04 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:05:32 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:10:04 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:11:09 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:11:54 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:14:58 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:15:40 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:19:18 --> Query error: Unknown column 'no_ident' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00', NULL)
ERROR - 2015-09-09 19:20:49 --> Severity: Error --> Call to a member function concepto_data_insert() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-09 19:22:18 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 19:23:30 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 19:25:46 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 19:26:46 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 19:30:49 --> Query error: Unknown column '4FFB3E12-5CF2-AA48-B533-986FAC14F7DA' in 'field list' - Invalid query: INSERT INTO `concepto` (`4FFB3E12-5CF2-AA48-B533-986FAC14F7DA`) VALUES ('')
ERROR - 2015-09-09 19:31:43 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `proveedor` (`rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 19:33:01 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-09 19:34:16 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `factura` (`rfc`, `rfc_nom`, `fecha`, `subtotal`, `moneda`, `total`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-09 19:34:29 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-09 19:36:07 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-09 19:36:48 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `proveedor` (`rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES (NULL, NULL, 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710')
ERROR - 2015-09-09 19:39:54 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `proveedor` (`rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES (NULL, NULL, 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710')
ERROR - 2015-09-09 19:44:42 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `proveedor` (`rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES (NULL, NULL, 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710')
ERROR - 2015-09-09 19:50:30 --> Query error: Column 'rfc_nom' cannot be null - Invalid query: INSERT INTO `proveedor` (`id_rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES ('NOR041213MX4', NULL, 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710')
ERROR - 2015-09-09 19:54:10 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `factura` (`rfc_nom`, `fecha`, `subtotal`, `moneda`, `total`, `rfc`) VALUES ('NORDATA, S.A. DE C.V.', '2015-08-03T12:10:26', '112.00', 'USD', '129.92', NULL)
ERROR - 2015-09-09 19:58:10 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `factura` (`rfc_nom`, `fecha`, `subtotal`, `moneda`, `total`, `rfc`) VALUES ('NORDATA, S.A. DE C.V.', '2015-08-03T12:10:26', '112.00', 'USD', '129.92', NULL)
ERROR - 2015-09-09 20:37:36 --> Severity: Parsing Error --> syntax error, unexpected '$cantidad' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-09 20:39:34 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-09 20:39:57 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 776
