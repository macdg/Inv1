<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-25 13:25:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 32
ERROR - 2015-09-25 13:43:51 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 123
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-25 14:57:14 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 123
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-25 14:58:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 123
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller2.php 124
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller2.php 125
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-25 14:59:21 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-25 20:17:07 --> Query error: Duplicate entry '0' for key 'id_productos' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '3', 'pz', 'BALUN NEO BNC FEMALE TO RJ45 CCITT G703', '45.0000')
ERROR - 2015-09-25 20:18:50 --> Query error: Duplicate entry '0' for key 'id_productos' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '3', 'pz', 'BALUN NEO BNC FEMALE TO RJ45 CCITT G703', '45.0000')
ERROR - 2015-09-25 20:42:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`almacen`.`productos`, CONSTRAINT `id_productos` FOREIGN KEY (`id_productos`) REFERENCES `concepto` (`id_concepto`) ON DELETE NO ACTION ON UPDATE NO ACTION) - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES ('4', '0001')
ERROR - 2015-09-25 20:45:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`almacen`.`productos`, CONSTRAINT `id_productos` FOREIGN KEY (`id_productos`) REFERENCES `concepto` (`id_concepto`) ON DELETE NO ACTION ON UPDATE NO ACTION) - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES ('4', '0001')
ERROR - 2015-09-25 20:49:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`almacen`.`productos`, CONSTRAINT `id_productos` FOREIGN KEY (`id_productos`) REFERENCES `concepto` (`id_concepto`) ON DELETE NO ACTION ON UPDATE NO ACTION) - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES ('4', '0001')
