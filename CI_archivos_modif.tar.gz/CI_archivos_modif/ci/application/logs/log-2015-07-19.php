<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: mdata /var/www/ci/application/views/d_new_view.php 68
ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:11:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:31:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: mdata /var/www/ci/application/views/d_new_view.php 68
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:31:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:31:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: mdata /var/www/ci/application/views/d_new_view.php 68
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:37:13 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:38:09 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:38:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:38:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:38:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:38:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:38:09 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:38:33 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:38:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:38:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:38:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:38:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:38:33 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:40:50 --> Severity: Notice --> Undefined variable: mi_file /var/www/ci/application/controllers/D_new_controller.php 10
ERROR - 2015-07-19 10:40:50 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:40:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:40:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:40:50 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:42:44 --> Severity: Notice --> Undefined variable: mi_file /var/www/ci/application/controllers/D_new_controller.php 10
ERROR - 2015-07-19 10:42:44 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:42:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:42:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:42:44 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:43:16 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:43:16 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:43:16 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:43:16 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:43:38 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:43:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:43:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:43:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:43:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:43:38 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:44:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:44:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:44:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:44:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:44:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:44:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:46:32 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:46:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:46:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:46:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:46:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:46:32 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 10:48:09 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 10:48:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 10:48:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 10:48:09 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:25:14 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/ci/application/controllers/D_new_controller.php 30
ERROR - 2015-07-19 13:26:03 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/ci/application/controllers/D_new_controller.php 30
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:27:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:27:14 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:43:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 13:44:52 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 14:03:42 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Use of undefined constant d_new_view - assumed 'd_new_view' /var/www/ci/application/controllers/D_new_controller.php 30
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 14:35:04 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 14:59:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:08:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:09:25 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:13:39 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:15:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:32:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:01 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:03 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:33:18 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:34:14 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:34:15 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:34:36 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:39:09 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:41:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:42:59 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:46:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:46:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:46:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:46:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:46:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:48:27 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 75
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 15:49:39 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: micadena /var/www/ci/application/views/d_new_view.php 76
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:38 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:57:57 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 70
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:58:35 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:59:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/ci/application/views/d_new_view.php 74
ERROR - 2015-07-19 16:59:43 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:59:43 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:59:43 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:59:43 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 16:59:43 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 16:59:43 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:00:49 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:00:49 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:00:49 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:00:49 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:00:49 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:00:49 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 26
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:10 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:20 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:20 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:20 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:20 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:01:20 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:01:20 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:02:19 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:02:19 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:02:19 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:02:19 --> Severity: Notice --> Undefined variable: cadenas /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 22
ERROR - 2015-07-19 17:02:19 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:02:19 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:05:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:05:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:05:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:05:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:06:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:06:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:06:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:06:33 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:07:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:07:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:07:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:07:00 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:13:21 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:13:21 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:13:21 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 84
ERROR - 2015-07-19 17:14:46 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:14:46 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:14:46 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 84
ERROR - 2015-07-19 17:14:47 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:14:47 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:14:47 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 84
ERROR - 2015-07-19 17:15:31 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:15:31 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:15:31 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:16:52 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:16:52 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:16:52 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:16:54 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:16:54 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:16:54 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:08 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:08 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:08 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:26 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:26 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:26 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:28 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:28 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:28 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:29 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:29 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:29 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:42 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:42 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:42 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:43 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:43 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:43 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /var/www/ci/application/views/d_new_view.php 85
ERROR - 2015-07-19 17:17:49 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:49 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:17:49 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:18:05 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: x /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: x_valor /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:18:05 --> Severity: Warning --> array_combine() expects parameter 1 to be array, null given /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: x /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: x_valor /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:18:05 --> Severity: Warning --> array_combine() expects parameter 1 to be array, null given /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:18:05 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: key /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:19:11 --> Severity: Warning --> array_combine() expects parameter 2 to be array, null given /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: x /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: x_valor /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:19:11 --> Severity: Warning --> array_combine() expects parameter 1 to be array, null given /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: x /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: x_valor /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:19:11 --> Severity: Warning --> array_combine() expects parameter 1 to be array, null given /var/www/ci/application/views/d_new_view.php 83
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:19:11 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-19 17:19:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:32 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:19:32 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:19:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:19:32 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:19:32 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:56:37 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:56:37 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:56:37 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:56:37 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:56:37 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:56:37 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:59:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:59:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:59:08 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:59:08 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:59:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:59:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 17:59:08 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 17:59:08 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:11:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:11:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:11:15 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:11:15 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:11:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:11:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:11:15 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:11:15 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:21 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:22 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:22 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:22 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:22 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:22 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:13:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:13:47 --> Severity: Notice --> Undefined variable: del_read_file /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:14:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:14:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:14:52 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:14:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:14:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 78
ERROR - 2015-07-19 18:14:52 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-19 18:28:40 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/ci/application/views/d_new_view.php 30
ERROR - 2015-07-19 19:01:32 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/ci/system/core/Loader.php 1336
ERROR - 2015-07-19 19:10:46 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/ci/system/core/Loader.php 1336
ERROR - 2015-07-19 19:14:39 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/ci/application/controllers/D_new_controller.php 45
ERROR - 2015-07-19 19:15:05 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/ci/application/views/d_new_view.php 24
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Benchmark could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Hooks could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Config could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Log could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Utf8 could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_URI could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Router could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Output could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Security could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Lang could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 19:43:06 --> Severity: 4096 --> Object of class CI_Upload could not be converted to string /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 20:06:23 --> Severity: Error --> Cannot access empty property /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:13:09 --> Severity: Notice --> Undefined variable: ARREGLO /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 20:15:20 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/ci/application/controllers/D_new_controller.php 34
ERROR - 2015-07-19 20:33:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/ci/application/controllers/D_new_controller.php 19
ERROR - 2015-07-19 20:34:14 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 19
ERROR - 2015-07-19 20:41:11 --> Severity: Notice --> Undefined variable: get_filenames /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:41:11 --> Severity: Error --> Function name must be a string /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:41:56 --> Severity: Parsing Error --> syntax error, unexpected 'as' (T_AS) /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:42:43 --> Severity: Parsing Error --> syntax error, unexpected '$key' (T_VARIABLE) /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:42:45 --> Severity: Parsing Error --> syntax error, unexpected '$key' (T_VARIABLE) /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:43:02 --> Severity: Parsing Error --> syntax error, unexpected 'as' (T_AS) /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:43:19 --> Severity: Parsing Error --> syntax error, unexpected '$value' (T_VARIABLE) /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:43:30 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/ci/application/controllers/D_new_controller.php 24
ERROR - 2015-07-19 20:44:04 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/ci/application/controllers/D_new_controller.php 25
ERROR - 2015-07-19 20:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/controllers/D_new_controller.php 23
ERROR - 2015-07-19 20:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/controllers/D_new_controller.php 23
ERROR - 2015-07-19 20:52:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/controllers/D_new_controller.php 23
