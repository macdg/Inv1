<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-13 18:53:31 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/ci/application/controllers/Trab_control.php 5
ERROR - 2015-07-13 19:13:07 --> Unable to load the requested class: Trabajando
ERROR - 2015-07-13 19:46:31 --> Severity: Notice --> Undefined variable: config /var/www/ci/application/controllers/Trab_control.php 7
ERROR - 2015-07-13 19:47:48 --> Severity: Notice --> Undefined variable: config /var/www/ci/application/controllers/Trab_control.php 7
ERROR - 2015-07-13 19:55:41 --> 404 Page Not Found: Trab_control/images
ERROR - 2015-07-13 19:55:41 --> 404 Page Not Found: Trab_control/images
ERROR - 2015-07-13 19:55:48 --> 404 Page Not Found: Trab_control/images
ERROR - 2015-07-13 19:56:32 --> Severity: Error --> Call to undefined function base_url() /var/www/ci/application/views/trabajando.php 11
ERROR - 2015-07-13 19:57:26 --> 404 Page Not Found: Trab_control/images
ERROR - 2015-07-13 19:58:03 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/ci/application/views/trabajando.php 12
