<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-04 09:35:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 09:35:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 09:35:37 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 09:46:39 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-04 09:47:05 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 09:47:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 09:47:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 09:48:27 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 09:48:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 09:48:27 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:00:22 --> Severity: Parsing Error --> syntax error, unexpected '&' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-04 10:02:26 --> Severity: Parsing Error --> syntax error, unexpected '&' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-04 10:02:43 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:02:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:02:43 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:02:47 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 103
ERROR - 2015-09-04 10:03:46 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:03:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:03:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:03:51 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-04 10:04:05 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 72
ERROR - 2015-09-04 10:04:05 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-04 10:04:19 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:04:19 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:04:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:04:23 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-04 10:05:11 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 72
ERROR - 2015-09-04 10:05:11 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-04 10:05:18 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-04 10:06:40 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:06:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:06:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:07:00 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-04 10:08:38 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:08:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:08:38 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:09:00 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:09:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:09:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:09:20 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:09:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:09:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:09:39 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:09:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:09:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:10:57 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:10:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:10:57 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:11:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 130
ERROR - 2015-09-04 10:11:02 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 134
ERROR - 2015-09-04 10:11:26 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:11:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:11:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:11:30 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 105
ERROR - 2015-09-04 10:11:40 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:11:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:11:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:11:45 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 105
ERROR - 2015-09-04 10:12:07 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:12:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:12:07 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:12:11 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 105
ERROR - 2015-09-04 10:13:12 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:13:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:13:12 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:13:16 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 105
ERROR - 2015-09-04 10:13:38 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:13:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:13:38 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:13:42 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-04 10:13:53 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:13:53 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:13:53 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:13:57 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-04 10:14:15 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:14:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:14:20 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-04 10:15:17 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:15:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:15:17 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:16:50 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:16:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:16:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:16:54 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-04 10:17:15 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-04 10:17:45 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:17:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:17:45 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:17:49 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 131
ERROR - 2015-09-04 10:17:49 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 135
ERROR - 2015-09-04 10:19:03 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 72
ERROR - 2015-09-04 10:19:03 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-04 10:19:03 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 134
ERROR - 2015-09-04 10:19:03 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 138
ERROR - 2015-09-04 10:19:07 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:19:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:19:07 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:19:11 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 134
ERROR - 2015-09-04 10:19:11 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 138
ERROR - 2015-09-04 10:19:41 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:19:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:19:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:19:46 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 134
ERROR - 2015-09-04 10:19:46 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 137
ERROR - 2015-09-04 10:20:23 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:20:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:20:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:20:27 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 134
ERROR - 2015-09-04 10:20:27 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 137
ERROR - 2015-09-04 10:23:01 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 135
ERROR - 2015-09-04 10:23:05 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 135
ERROR - 2015-09-04 10:23:17 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 135
ERROR - 2015-09-04 10:25:14 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 135
ERROR - 2015-09-04 10:25:28 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 135
ERROR - 2015-09-04 10:26:15 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:26:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:26:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:26:19 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-04 10:26:19 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-04 10:26:59 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:26:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:26:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 10:27:03 --> Severity: Notice --> Undefined variable: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-04 10:27:03 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-04 10:27:46 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 10:27:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 10:27:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:34:24 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 142
ERROR - 2015-09-04 12:35:27 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:35:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:35:27 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:36:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:36:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:36:37 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:43:23 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:43:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:43:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:44:59 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:44:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:44:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:52:08 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:52:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:52:08 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:52:32 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:52:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:52:32 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 12:54:34 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 12:54:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 12:54:34 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 13:13:13 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 13:13:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 13:13:13 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 13:46:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 13:46:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 13:46:10 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 13:47:28 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 13:47:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 13:47:28 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 13:53:33 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 13:53:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 13:53:33 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 13:53:37 --> Severity: Notice --> Undefined variable: tip_arch /var/www/html/ci/application/controllers/B_up_xml_controller1.php 169
ERROR - 2015-09-04 13:53:37 --> Severity: Notice --> Undefined variable: nombreDirectorio /var/www/html/ci/application/controllers/B_up_xml_controller1.php 169
ERROR - 2015-09-04 13:53:37 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 169
ERROR - 2015-09-04 13:53:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:170) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-04 13:53:37 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 170
ERROR - 2015-09-04 13:57:45 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 13:57:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 13:57:45 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 13:57:48 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 171
ERROR - 2015-09-04 13:57:48 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 171
ERROR - 2015-09-04 13:57:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:172) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-04 13:57:48 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 172
ERROR - 2015-09-04 14:00:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 14:00:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 14:00:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 14:00:58 --> Severity: Warning --> file_get_contents(NOR041213MX4_Factura_XFA2747_20150803.xml): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/B_up_xml_controller1.php 171
ERROR - 2015-09-04 14:00:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:172) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-04 14:00:58 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 172
ERROR - 2015-09-04 14:04:12 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 14:04:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 14:04:12 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 14:04:17 --> Severity: Warning --> file_get_contents(NOR041213MX4_Factura_XFA2747_20150803.xml): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/B_up_xml_controller1.php 171
ERROR - 2015-09-04 14:04:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:172) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-04 14:04:17 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 172
ERROR - 2015-09-04 14:05:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 14:05:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 14:05:37 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 14:05:42 --> Severity: Warning --> file_get_contents(NOR041213MX4_Factura_XFA2747_20150803.xml): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/B_up_xml_controller1.php 172
ERROR - 2015-09-04 14:06:29 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 14:06:29 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 14:06:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 14:07:39 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 14:07:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 14:07:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 14:10:58 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-04 14:10:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-04 14:10:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-04 15:11:35 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:11:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:11:35 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 187
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 74
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined variable: nombreDirectorio /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-04 15:13:04 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 173
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 187
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-04 15:13:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-04 15:13:04 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-04 15:13:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-04 15:15:22 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:15:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:15:22 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 187
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:15:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:18:25 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:18:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:18:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:18:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:19:15 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:19:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:19:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 187
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:19:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:22:08 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:22:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:22:08 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined variable: nombreDirectorio /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-04 15:22:55 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 173
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 187
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-04 15:22:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-04 15:22:55 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-04 15:22:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-04 15:25:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:25:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:25:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 187
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:25:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-04 15:27:13 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:27:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:27:13 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:34:58 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:34:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:34:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:35:45 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:35:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:35:45 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 15:36:51 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 15:36:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 15:36:51 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:00:36 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:00:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:00:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:00:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:01:42 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:01:42 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:01:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:01:42 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:01:50 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:01:50 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:01:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:01:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:03:20 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:03:20 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:03:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:03:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:04:42 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:04:42 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:04:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:04:42 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:05:29 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:05:29 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:05:29 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:05:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:07:12 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:07:12 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:07:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:07:12 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:08:04 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:08:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:08:04 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:08:29 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:08:29 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:08:29 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:09:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:09:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:09:10 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:10:44 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:10:44 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:10:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:10:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:11:36 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:11:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:11:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:11:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:12:11 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:12:38 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:12:38 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:12:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:12:38 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:13:14 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:13:14 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:13:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:13:14 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:41:33 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:41:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:41:33 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:43:28 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:43:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:43:28 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:45:00 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/views/b_subirgeneral1_view.php 20
ERROR - 2015-09-04 16:45:00 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:45:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:45:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 16:57:53 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 16:57:53 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:57:53 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:57:57 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 16:57:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:57:57 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:59:42 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 16:59:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:59:42 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 16:59:57 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 16:59:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 16:59:57 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 17:00:35 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:00:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:00:35 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 17:06:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:06:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 17:06:10 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 17:06:19 --> Severity: Notice --> Undefined variable: cadenita /var/www/html/ci/application/controllers/B_up_xml_controller1.php 197
ERROR - 2015-09-04 17:06:59 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:06:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 17:06:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 17:07:33 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:07:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 17:07:33 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 17:17:40 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 47
ERROR - 2015-09-04 17:17:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 48
ERROR - 2015-09-04 17:17:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 49
ERROR - 2015-09-04 17:24:03 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:24:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:24:03 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:27:45 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:27:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:27:45 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:27:45 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::seleccionando_opcion_xml(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 62 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 185
ERROR - 2015-09-04 17:33:34 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:33:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:33:34 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:33:38 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 203
ERROR - 2015-09-04 17:33:38 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 204
ERROR - 2015-09-04 17:35:31 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:35:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:35:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:35:35 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::seleccionando_opcion_xml(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 180 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 185
ERROR - 2015-09-04 17:35:35 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 204
ERROR - 2015-09-04 17:36:17 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:36:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:36:17 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:36:20 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::seleccionando_opcion_xml(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 180 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 185
ERROR - 2015-09-04 17:36:20 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 203
ERROR - 2015-09-04 17:36:20 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 204
ERROR - 2015-09-04 17:38:18 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:38:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:38:18 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:51:33 --> Severity: Error --> Call to undefined method CI_Loader::seleccionando_opcion_xml() /var/www/html/ci/application/views/b_subirgeneral1_view.php 21
ERROR - 2015-09-04 17:51:47 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::seleccionando_opcion_xml(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 180 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 185
ERROR - 2015-09-04 17:51:47 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 198
ERROR - 2015-09-04 17:55:26 --> Severity: Error --> Call to undefined method CI_Loader::seleccionando_opcion_xml() /var/www/html/ci/application/views/b_subirgeneral1_view.php 21
ERROR - 2015-09-04 17:56:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-04 17:56:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-04 17:56:10 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-04 17:56:17 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::seleccionando_opcion_xml(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 178 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 183
ERROR - 2015-09-04 17:56:17 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 196
