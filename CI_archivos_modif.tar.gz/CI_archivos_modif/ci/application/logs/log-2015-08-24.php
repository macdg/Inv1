<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-24 10:33:52 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-24 10:33:52 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-24 10:33:52 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-24 10:33:52 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-24 11:29:35 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-24 11:29:35 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-24 11:29:35 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-24 11:29:35 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-24 14:33:50 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) /var/www/html/ci/application/controllers/Up_xml_controller1.php 265
ERROR - 2015-08-24 14:34:10 --> Severity: Parsing Error --> syntax error, unexpected '$id_datos' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller1.php 265
ERROR - 2015-08-24 14:44:28 --> Severity: Warning --> Missing argument 1 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:44:28 --> Severity: Warning --> Missing argument 2 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:44:28 --> Severity: Warning --> Missing argument 3 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:44:28 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/Up_xml_controller1.php 267
ERROR - 2015-08-24 14:45:58 --> Severity: Warning --> Missing argument 1 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:45:58 --> Severity: Warning --> Missing argument 2 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:45:58 --> Severity: Warning --> Missing argument 3 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:45:58 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/Up_xml_controller1.php 267
ERROR - 2015-08-24 14:54:34 --> Severity: Warning --> Missing argument 1 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:54:34 --> Severity: Warning --> Missing argument 2 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:54:34 --> Severity: Warning --> Missing argument 3 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:54:34 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/Up_xml_controller1.php 267
ERROR - 2015-08-24 14:54:51 --> Severity: Warning --> Missing argument 1 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:54:51 --> Severity: Warning --> Missing argument 2 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:54:51 --> Severity: Warning --> Missing argument 3 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 14:54:51 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/Up_xml_controller1.php 267
ERROR - 2015-08-24 15:02:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/Up_xml_controller1.php 285
ERROR - 2015-08-24 15:02:35 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/Up_xml_controller1.php 285
ERROR - 2015-08-24 15:50:31 --> Severity: Warning --> Missing argument 1 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 15:50:31 --> Severity: Warning --> Missing argument 2 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 15:50:31 --> Severity: Warning --> Missing argument 3 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 15:50:31 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/Up_xml_controller1.php 267
ERROR - 2015-08-24 15:52:22 --> Severity: Warning --> Missing argument 1 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 15:52:22 --> Severity: Warning --> Missing argument 2 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 15:52:22 --> Severity: Warning --> Missing argument 3 for Up_xml_controller1::in_dat() /var/www/html/ci/application/controllers/Up_xml_controller1.php 263
ERROR - 2015-08-24 15:52:22 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/Up_xml_controller1.php 267
ERROR - 2015-08-24 16:24:09 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 12
ERROR - 2015-08-24 16:24:58 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 12
ERROR - 2015-08-24 16:43:36 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC) /var/www/html/ci/application/views/up_xml_in_view1.php 49
ERROR - 2015-08-24 16:49:23 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' /var/www/html/ci/application/views/up_xml_in_view1.php 46
ERROR - 2015-08-24 18:05:47 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 18:06:43 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 18:11:26 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 18:12:15 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 18:12:53 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 18:13:47 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 18:15:36 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller1.php 235
ERROR - 2015-08-24 18:16:28 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller1.php 235
ERROR - 2015-08-24 18:16:51 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller1.php 235
ERROR - 2015-08-24 18:18:22 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller1.php 235
ERROR - 2015-08-24 18:34:01 --> Severity: Error --> Maximum execution time of 200 seconds exceeded /var/www/html/ci/system/core/Common.php 612
ERROR - 2015-08-24 18:52:45 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/Up_xml_controller1.php 219
ERROR - 2015-08-24 18:53:34 --> Severity: Parsing Error --> syntax error, unexpected '$descrip' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller1.php 219
ERROR - 2015-08-24 19:02:33 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 219
ERROR - 2015-08-24 19:03:32 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 219
ERROR - 2015-08-24 19:04:42 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) /var/www/html/ci/application/controllers/Up_xml_controller1.php 219
ERROR - 2015-08-24 19:18:54 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:19:31 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:20:44 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:22:08 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:22:55 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:29:19 --> Severity: Parsing Error --> syntax error, unexpected '$key' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller1.php 243
ERROR - 2015-08-24 19:36:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:37:02 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:38:21 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:39:09 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:41:57 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:42:00 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:42:00 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:42:01 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:42:01 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/Up_xml_controller1.php 214
ERROR - 2015-08-24 19:51:04 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:52:39 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:54:34 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:56:56 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 19:57:48 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
ERROR - 2015-08-24 20:13:10 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 29
