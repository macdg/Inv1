<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-02 14:21:32 --> Severity: Parsing Error --> syntax error, unexpected '1' (T_LNUMBER) /var/www/html/ci/application/views/b_up_xml_view.php 24
ERROR - 2015-09-02 15:17:38 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/pagina_exito.php 12
ERROR - 2015-09-02 15:18:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/pagina_exito.php 12
ERROR - 2015-09-02 15:49:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-02 15:49:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 11
ERROR - 2015-09-02 15:49:58 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 17
ERROR - 2015-09-02 15:49:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 23
ERROR - 2015-09-02 15:49:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-02 15:49:58 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-02 16:02:32 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-02 16:02:32 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 11
ERROR - 2015-09-02 16:02:32 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 17
ERROR - 2015-09-02 16:02:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 23
ERROR - 2015-09-02 16:02:32 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-02 16:02:32 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-02 16:05:10 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-02 16:05:10 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 11
ERROR - 2015-09-02 16:05:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 17
ERROR - 2015-09-02 16:05:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 23
ERROR - 2015-09-02 16:05:10 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-02 16:05:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-02 16:25:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 44
ERROR - 2015-09-02 16:25:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 45
ERROR - 2015-09-02 16:25:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 46
ERROR - 2015-09-02 16:28:04 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 44
ERROR - 2015-09-02 16:28:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 45
ERROR - 2015-09-02 16:28:04 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 46
ERROR - 2015-09-02 16:34:47 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 40
ERROR - 2015-09-02 16:34:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 41
ERROR - 2015-09-02 16:34:47 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 42
ERROR - 2015-09-02 16:35:59 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 41
ERROR - 2015-09-02 16:35:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 42
ERROR - 2015-09-02 16:35:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 43
ERROR - 2015-09-02 16:39:26 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 41
ERROR - 2015-09-02 16:39:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 42
ERROR - 2015-09-02 16:39:26 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 43
ERROR - 2015-09-02 16:40:42 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 41
ERROR - 2015-09-02 16:40:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 42
ERROR - 2015-09-02 16:40:42 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 43
ERROR - 2015-09-02 16:43:39 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 41
ERROR - 2015-09-02 16:43:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 42
ERROR - 2015-09-02 16:43:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 43
ERROR - 2015-09-02 16:44:38 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubir_view.php 41
ERROR - 2015-09-02 16:44:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubir_view.php 42
ERROR - 2015-09-02 16:44:38 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubir_view.php 43
ERROR - 2015-09-02 16:54:03 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubirgeneral_view.php 41
ERROR - 2015-09-02 16:54:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubirgeneral_view.php 42
ERROR - 2015-09-02 16:54:03 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubirgeneral_view.php 43
ERROR - 2015-09-02 17:07:19 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubirgeneral_view.php 41
ERROR - 2015-09-02 17:07:19 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubirgeneral_view.php 42
ERROR - 2015-09-02 17:07:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubirgeneral_view.php 43
ERROR - 2015-09-02 17:08:42 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_upsubirgeneral_view.php 41
ERROR - 2015-09-02 17:08:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_upsubirgeneral_view.php 42
ERROR - 2015-09-02 17:08:42 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_upsubirgeneral_view.php 43
ERROR - 2015-09-02 17:14:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 17:14:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 17:14:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 17:59:09 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 17:59:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 17:59:09 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 17:59:59 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 17:59:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 17:59:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:17:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:17:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:17:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:48:07 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:48:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:48:07 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:48:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:48:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:48:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:51:23 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:51:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:51:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:53:33 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:53:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:53:33 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:55:07 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:55:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:55:07 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:55:48 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:55:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:55:48 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 18:58:19 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 18:58:19 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 18:58:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:02:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:02:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:02:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:03:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:03:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:03:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:05:44 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:05:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:05:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:11:39 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:11:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:11:39 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:14:01 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:20:55 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:21:59 --> Severity: Compile Error --> Call-time pass-by-reference has been removed /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:22:17 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:29:11 --> Severity: Error --> Call to undefined method CI_Controller::subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:44:44 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:44:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:44:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:44:56 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:44:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:44:56 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 19:51:45 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 19:51:45 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 19:51:45 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 19:52:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:52:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 19:52:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 19:52:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 19:54:10 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-02 19:54:10 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 19:54:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 19:54:10 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 19:54:10 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 19:59:02 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 19:59:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 19:59:02 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 20:00:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 20:00:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 20:00:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 20:02:34 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-02 20:02:34 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 20:02:34 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:02:34 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 20:02:34 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 20:04:27 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 20:04:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 20:04:27 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 20:07:41 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-02 20:07:59 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-02 20:08:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-02 20:08:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-02 20:08:54 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-02 20:09:07 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-02 20:10:00 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-02 20:10:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-02 20:10:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-02 20:10:18 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-02 20:10:18 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 20:10:18 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:10:18 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 20:10:18 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 20:10:39 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 20:10:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:10:39 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 20:10:39 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 20:11:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:11:06 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-02 20:11:06 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-02 20:11:36 --> Severity: Error --> Call to undefined method CI_Loader::subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 20:12:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:12:00 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-02 20:12:26 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:12:26 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-02 20:12:40 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 20:12:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:12:40 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-02 20:12:53 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-02 20:12:53 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-02 20:12:53 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-02 20:12:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:109) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-02 20:12:53 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
