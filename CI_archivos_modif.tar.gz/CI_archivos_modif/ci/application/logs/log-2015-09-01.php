<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-01 10:55:38 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`cantidad`) VALUES (NULL)
ERROR - 2015-09-01 11:00:02 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`cantidad`) VALUES (NULL)
ERROR - 2015-09-01 11:01:39 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:04:56 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:07:28 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:09:12 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:10:38 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:11:13 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:14:27 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('')
ERROR - 2015-09-01 11:17:58 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES (0)
ERROR - 2015-09-01 11:28:34 --> Query error: Unknown column 'id_productos' in 'field list' - Invalid query: INSERT INTO `productos` (`id_productos`) VALUES ('0')
ERROR - 2015-09-01 11:30:54 --> Query error: Table 'almacen.producto' doesn't exist - Invalid query: INSERT INTO `producto` (`id_producto`) VALUES ('0')
ERROR - 2015-09-01 11:39:50 --> Query error: Table 'almacen.producto' doesn't exist - Invalid query: INSERT INTO `producto` (`id_producto`) VALUES ('0')
ERROR - 2015-09-01 11:42:06 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Input.php 173
ERROR - 2015-09-01 11:49:32 --> Query error: Unknown column 'submit' in 'field list' - Invalid query: INSERT INTO `productos` (`submit`) VALUES ('Subir')
ERROR - 2015-09-01 11:51:14 --> Query error: Unknown column 'submit' in 'field list' - Invalid query: INSERT INTO `productos` (`submit`) VALUES ('Subir')
ERROR - 2015-09-01 11:52:11 --> Query error: Unknown column 'submit' in 'field list' - Invalid query: INSERT INTO `productos` (`submit`) VALUES ('Subir')
ERROR - 2015-09-01 12:21:00 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/models/Up_xml_model.php 71
ERROR - 2015-09-01 12:22:29 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/models/Up_xml_model.php 72
ERROR - 2015-09-01 12:24:28 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`cantidad`, `unidad`, `modelo`, `descripcion`, `valorunitario`, `fecha_ingreso`, `noserie`, `nopieza`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-01 12:35:11 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 56
ERROR - 2015-09-01 12:38:56 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 103
ERROR - 2015-09-01 13:31:57 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`cantidad`, `unidad`, `modelo`, `descripcion`, `valorunitario`, `fecha_ingreso`, `noserie`, `nopieza`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-01 19:38:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 45
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 57
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: nombreDirectorio /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: nombreDirectorio /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 153
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 153
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 168
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 168
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 195
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 195
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 265
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/ci/application/controllers/B_up_xml_controller1.php 265
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 281
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 281
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/B_up_xml_controller1.php 321
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 322
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: descrip_xml1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 323
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 324
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: cant_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 325
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: descrip_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 326
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/B_up_xml_controller1.php 385
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 385
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/up_xml_in_view1a.php 11
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/up_xml_in_view1a.php 40
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/controllers/B_up_xml_controller1.php 386
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: cant_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 386
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Undefined variable: descrip_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 386
ERROR - 2015-09-01 19:39:00 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/up_xml_in_view1.php 6
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_in_view1.php 42
ERROR - 2015-09-01 19:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_in_view1.php 50
