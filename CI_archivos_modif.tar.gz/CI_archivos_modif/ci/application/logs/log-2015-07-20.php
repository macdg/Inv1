<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-20 09:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/controllers/D_new_controller.php 23
ERROR - 2015-07-20 10:59:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/controllers/D_new_controller.php 23
ERROR - 2015-07-20 11:10:01 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:10:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:10:48 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:48 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:50 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:50 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:55 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:55 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:56 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:56 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:57 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:57 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:57 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:58 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:10:58 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:11:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:11:44 --> Severity: Notice --> Undefined variable: col /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:14:37 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:14:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:17:24 --> Severity: Notice --> Use of undefined constant vector - assumed 'vector' /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 11:17:24 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:17:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:23:05 --> Severity: Notice --> Use of undefined constant vector - assumed 'vector' /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 11:23:05 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:33:48 --> Severity: Notice --> Use of undefined constant carpeta - assumed 'carpeta' /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-20 11:33:48 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:33:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:34:45 --> Severity: Notice --> Use of undefined constant carpeta - assumed 'carpeta' /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-20 11:34:45 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:34:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:34:46 --> Severity: Notice --> Use of undefined constant carpeta - assumed 'carpeta' /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-20 11:34:46 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:38:49 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 11:38:49 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 11:40:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 11:40:15 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:36 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:40:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:36 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:40:36 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:40:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:42:06 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:42:06 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:42:06 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:42:06 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:42:48 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:42:48 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:46:42 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:46:42 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:46:44 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:46:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:48:08 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/controllers/D_new_controller.php 22
ERROR - 2015-07-20 11:48:39 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:48:39 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:07 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:59:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:07 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:59:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:44 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:59:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:44 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:59:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:44 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 11:59:44 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 11:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:00:12 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:00:12 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:00:12 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:01:23 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:01:23 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:01:23 --> Severity: Notice --> Undefined variable: chango /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:03:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:03:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:03:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:03:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:03:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:03:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:03:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:03:47 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:08:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:08:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:08:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:08:08 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:10:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:10:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:10:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:10:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:10:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:13:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:13:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:13:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:13:21 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:14:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:14:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:14:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:14:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:14:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 34
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:45:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:18 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:46:20 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 31
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:12 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:47:53 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:50:30 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:52:38 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:32 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:54:33 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/application/views/d_new_view.php 35
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:55:23 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: c_hay /var/www/ci/application/views/d_new_view.php 32
ERROR - 2015-07-20 12:59:10 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/views/d_new_view.php 33
ERROR - 2015-07-20 14:04:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 27
ERROR - 2015-07-20 14:04:07 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 31
ERROR - 2015-07-20 14:04:52 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 33
ERROR - 2015-07-20 14:08:11 --> Severity: Notice --> Undefined variable: cadena /var/www/ci/application/controllers/D_new_controller.php 35
ERROR - 2015-07-20 14:28:52 --> Severity: Notice --> Undefined variable: c_hay1 /var/www/ci/application/views/d_new_view.php 68
ERROR - 2015-07-20 16:14:12 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:14:12 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:14:12 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:14:12 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:15:46 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:15:46 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:15:46 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:15:46 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:15:47 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:15:47 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:15:47 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:15:47 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:17:24 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/controllers/D_new_controller.php 94
ERROR - 2015-07-20 16:18:08 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/controllers/D_new_controller.php 94
ERROR - 2015-07-20 16:18:09 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/controllers/D_new_controller.php 94
ERROR - 2015-07-20 16:18:38 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:18:38 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:18:38 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:18:38 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:19:33 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:19:33 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:19:33 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:19:33 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:20:59 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:20:59 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:20:59 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/controllers/D_new_controller.php 93
ERROR - 2015-07-20 16:20:59 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:20:59 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:21:56 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:21:56 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:21:56 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:21:56 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:22:15 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:22:15 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:22:15 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:22:15 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:22:15 --> Severity: Notice --> Undefined variable: gatos /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:22:15 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:22 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:22 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:22 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:22 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:22 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:22 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:34 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:34 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:34 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:34 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:34 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:34 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:35 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:35 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:35 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:35 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:26:35 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:26:35 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:27:38 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:27:38 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:27:38 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:27:38 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:27:39 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:27:39 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:27:39 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:27:39 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 16:28:56 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:28:56 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:28:56 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:28:56 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:30:54 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:30:54 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:30:54 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:30:54 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:31:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:31:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:32:50 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:32:50 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:32:52 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:32:52 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:34:24 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:34:24 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:34:27 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:34:27 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:35:01 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:35:01 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:35:01 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:35:01 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:36:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:36:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:36:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:36:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:36:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:36:55 --> Severity: Notice --> Undefined variable: kk /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:39:12 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:39:12 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:39:12 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:39:12 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:39:12 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:39:12 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:39:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:39:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:39:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:39:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:39:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:39:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:44:19 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:44:19 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:45:11 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:45:11 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 16:46:01 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:46:23 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:46:44 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting '(' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:47:07 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:47:21 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:47:57 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:48:12 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:48:28 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 16:48:28 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:02:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:02:13 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:02:37 --> Severity: Notice --> Undefined variable: datos /var/www/ci/application/controllers/D_new_controller.php 95
ERROR - 2015-07-20 17:12:26 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:12:26 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:12:50 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:12:50 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:12:53 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:12:53 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:12:55 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:12:55 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:13:34 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:13:34 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:13:37 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:13:37 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:15:01 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:15:01 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:16:44 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-20 17:16:44 --> Severity: Notice --> Undefined variable: k /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 17:25:59 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:36:30 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:36:30 --> Severity: Notice --> Undefined variable: top_level_only /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:37:27 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:37:27 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:37:27 --> Severity: Notice --> Undefined variable: top_level_only /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:37:53 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:37:53 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:37:53 --> Severity: Notice --> Undefined variable: top_level_only /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:38:24 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:38:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:38:24 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:38:24 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:38:26 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:38:26 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:38:26 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:38:50 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:38:50 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:38:50 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:38:51 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:38:51 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:38:51 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:38:52 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:38:52 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:38:52 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:39:46 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:39:46 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:39:46 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/controllers/D_new_controller.php 104
ERROR - 2015-07-20 17:39:46 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:39:46 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:40:08 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:40:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:40:08 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:40:08 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/controllers/D_new_controller.php 104
ERROR - 2015-07-20 17:40:08 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:40:08 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:41:56 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:41:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:41:56 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:41:56 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:41:56 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:41:56 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 17:42:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/views/d_new_view.php 96
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/views/d_new_view.php 97
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/views/d_new_view.php 100
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:42:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:42:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 101
ERROR - 2015-07-20 17:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:44:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 101
ERROR - 2015-07-20 17:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:45:27 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 17:47:16 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:47:53 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:48:12 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:48:32 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:48:58 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:49:24 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:52:13 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant name - assumed 'name' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant server_path - assumed 'server_path' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant size - assumed 'size' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant date - assumed 'date' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant readable - assumed 'readable' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant writable - assumed 'writable' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant executable - assumed 'executable' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Use of undefined constant fileperms - assumed 'fileperms' /var/www/ci/application/controllers/D_new_controller.php 102
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 17:53:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 106
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 17:53:06 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant name - assumed 'name' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant server_path - assumed 'server_path' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant size - assumed 'size' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant date - assumed 'date' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant readable - assumed 'readable' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant writable - assumed 'writable' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant executable - assumed 'executable' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Use of undefined constant fileperms - assumed 'fileperms' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 104
ERROR - 2015-07-20 18:04:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:04:35 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 113
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant name - assumed 'name' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant server_path - assumed 'server_path' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant size - assumed 'size' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant date - assumed 'date' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant readable - assumed 'readable' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant writable - assumed 'writable' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant executable - assumed 'executable' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Use of undefined constant fileperms - assumed 'fileperms' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 104
ERROR - 2015-07-20 18:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:07:02 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 113
ERROR - 2015-07-20 18:10:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ci/system/helpers/file_helper.php 289
ERROR - 2015-07-20 18:10:53 --> Severity: Notice --> Undefined variable: fileinfo /var/www/ci/system/helpers/file_helper.php 320
ERROR - 2015-07-20 18:10:53 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 18:10:53 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:10:53 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:10:53 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 113
ERROR - 2015-07-20 18:11:51 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 18:11:51 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:11:51 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:11:51 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 113
ERROR - 2015-07-20 18:13:33 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 107
ERROR - 2015-07-20 18:13:33 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:13:33 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:13:33 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 113
ERROR - 2015-07-20 18:15:29 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 18:15:29 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:15:29 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 18:15:29 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-07-20 18:16:15 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 18:16:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:16:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 18:16:15 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-07-20 18:16:53 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/ci/application/controllers/D_new_controller.php 103
ERROR - 2015-07-20 18:17:12 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 108
ERROR - 2015-07-20 18:17:12 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 110
ERROR - 2015-07-20 18:17:12 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 18:17:12 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-07-20 18:18:50 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:18:50 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 18:18:50 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-07-20 18:18:50 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 115
ERROR - 2015-07-20 18:19:16 --> Severity: Notice --> Undefined variable: info2 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 18:19:16 --> Severity: Notice --> Undefined variable: info2 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 18:19:16 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:19:16 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 111
ERROR - 2015-07-20 18:19:16 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-07-20 18:19:16 --> Severity: Notice --> Undefined variable: file_information /var/www/ci/application/controllers/D_new_controller.php 115
ERROR - 2015-07-20 18:20:43 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:21:15 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:22:06 --> Severity: Notice --> Array to string conversion /var/www/ci/application/controllers/D_new_controller.php 109
ERROR - 2015-07-20 18:23:05 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 18:23:05 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-20 18:23:45 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-20 18:23:45 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-20 18:29:28 --> Severity: Warning --> fileperms(): stat failed for ./archivo.php /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 18:29:28 --> Severity: Warning --> fileperms(): stat failed for ./archivo.php /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-20 18:31:34 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-20 18:31:34 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-20 18:36:47 --> Severity: Warning --> readfile(archivo.txt): failed to open stream: No such file or directory /var/www/ci/application/views/d_new_view.php 97
ERROR - 2015-07-20 18:37:06 --> Severity: Warning --> readfile(archivo.txt): failed to open stream: No such file or directory /var/www/ci/application/views/d_new_view.php 97
ERROR - 2015-07-20 18:37:36 --> Severity: Warning --> readfile(archivo.php): failed to open stream: No such file or directory /var/www/ci/application/views/d_new_view.php 97
ERROR - 2015-07-20 18:50:38 --> Severity: Notice --> Array to string conversion /var/www/ci/system/core/Output.php 528
ERROR - 2015-07-20 19:00:43 --> Severity: Warning --> Missing argument 1 for CI_Output::cache(), called in /var/www/ci/application/controllers/D_new_controller.php on line 116 and defined /var/www/ci/system/core/Output.php 383
ERROR - 2015-07-20 19:00:43 --> Severity: Notice --> Undefined variable: time /var/www/ci/system/core/Output.php 385
ERROR - 2015-07-20 19:58:43 --> Unable to load the requested class: File
ERROR - 2015-07-20 19:59:32 --> Unable to load the requested class: File
ERROR - 2015-07-20 19:59:33 --> Unable to load the requested class: File
ERROR - 2015-07-20 19:59:34 --> Unable to load the requested class: File
ERROR - 2015-07-20 20:00:38 --> Unable to load the requested class: File
ERROR - 2015-07-20 20:00:39 --> Unable to load the requested class: File
ERROR - 2015-07-20 20:01:26 --> Unable to load the requested class: File
ERROR - 2015-07-20 20:02:22 --> Unable to load the requested class: File
ERROR - 2015-07-20 20:02:24 --> Unable to load the requested class: File
ERROR - 2015-07-20 20:02:49 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-20 20:04:23 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-20 20:04:25 --> Severity: Notice --> Undefined variable: info_carpeta /var/www/ci/application/views/d_new_view.php 92
