<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-27 12:00:11 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `proveedor` (`rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES ('NOR041213MX4', 'NORDATA, S.A. DE C.V.', 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710')
ERROR - 2015-08-27 13:52:34 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-27 13:52:35 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-27 13:52:35 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-27 13:52:35 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-27 13:52:35 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-27 13:53:22 --> Query error: Unknown column 'rfc' in 'field list' - Invalid query: INSERT INTO `proveedor` (`rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`) VALUES ('NOR041213MX4', 'NORDATA, S.A. DE C.V.', 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710')
ERROR - 2015-08-27 14:01:14 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
