<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-10 09:53:45 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view1.php 20
ERROR - 2015-08-10 09:53:45 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:53:45 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:53:49 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view1.php 20
ERROR - 2015-08-10 09:53:49 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:53:49 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:54:00 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view1.php 20
ERROR - 2015-08-10 09:54:00 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:54:00 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:54:04 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view1.php 20
ERROR - 2015-08-10 09:54:04 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:54:04 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:54:08 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view1.php 20
ERROR - 2015-08-10 09:54:08 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 09:54:08 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view1.php 195
ERROR - 2015-08-10 11:02:42 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-10 11:02:42 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-10 11:02:42 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
