<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-22 09:50:39 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', Array, Array, Array, Array)
ERROR - 2015-09-22 09:50:53 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-22 10:49:50 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/models/B_up_xml_model.php 22
ERROR - 2015-09-22 11:16:31 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:16:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:16:31 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:18:53 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:18:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:18:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:18:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:18:53 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:18:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 982
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 982
ERROR - 2015-09-22 11:29:10 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:34:19 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 995
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 954
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 958
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:34:58 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:36:26 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 967
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 983
ERROR - 2015-09-22 11:37:03 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 987
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:39:34 --> Severity: Notice --> Undefined index: array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 986
ERROR - 2015-09-22 11:40:43 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 990
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 992
ERROR - 2015-09-22 11:42:55 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 996
ERROR - 2015-09-22 11:50:12 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:50:12 --> Severity: Warning --> Missing argument 2 for B_up_xml_model::solicita_productos_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 947 and defined /var/www/html/ci/application/models/B_up_xml_model.php 110
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/models/B_up_xml_model.php 118
ERROR - 2015-09-22 11:50:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 11:50:12 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, NULL)
ERROR - 2015-09-22 11:50:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 11:52:41 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 11:52:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 11:52:41 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, Array)
ERROR - 2015-09-22 11:52:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 997
ERROR - 2015-09-22 11:53:17 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1003
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 999
ERROR - 2015-09-22 11:54:16 --> Severity: Notice --> Undefined offset: 7 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 11:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 1005
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:06:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:06:05 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, Array)
ERROR - 2015-09-22 12:06:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:12:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:12:43 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, Array)
ERROR - 2015-09-22 12:12:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 949
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 962
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:13:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:13:30 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, Array)
ERROR - 2015-09-22 12:13:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 12:26:57 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:26:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:26:57 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, Array)
ERROR - 2015-09-22 12:26:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 12:28:24 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:28:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:28:24 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, Array)
ERROR - 2015-09-22 12:28:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 12:30:19 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:30:19 --> Severity: Warning --> Missing argument 2 for B_up_xml_model::solicita_productos_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 958 and defined /var/www/html/ci/application/models/B_up_xml_model.php 110
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/models/B_up_xml_model.php 118
ERROR - 2015-09-22 12:30:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-22 12:30:19 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (Array, NULL)
ERROR - 2015-09-22 12:30:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-22 12:32:08 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:32:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:32:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 912
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 927
ERROR - 2015-09-22 12:32:08 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 928
ERROR - 2015-09-22 12:35:25 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:35:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:35:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:35:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:35:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:35:25 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:35:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:36:10 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 750
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 759
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 761
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 763
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 777
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 793
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:36:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 799
ERROR - 2015-09-22 12:36:10 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:36:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 873
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 579
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 586
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 625
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 12:43:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 12:45:07 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 557
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 571
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 601
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 607
ERROR - 2015-09-22 12:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 607
ERROR - 2015-09-22 12:45:07 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-22 12:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 570
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 609
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:49:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 570
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 609
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-22 12:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Undefined variable: oc_all_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 573
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 594
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 610
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 619
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 573
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:57:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 573
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 12:59:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Undefined variable: oc_all_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:00:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Undefined variable: oc_all_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:05:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Undefined variable: oc_var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:08:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Undefined variable: oc_var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:09:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Undefined variable: oc_var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:37:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:41:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:44:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:46:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:47:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:48:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:49:42 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/views/b_xmlcaso2_view.php 144
ERROR - 2015-09-22 13:50:14 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/views/b_xmlcaso2_view.php 144
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:50:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:51:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:53:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:55:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:57:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 13:59:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:00:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:02:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 565
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 582
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 611
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 620
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-22 14:07:53 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 14:16:21 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 557
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 564
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 566
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 597
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 613
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 622
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:16:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 557
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 564
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 566
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 597
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 613
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 622
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 14:18:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-22 14:26:21 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: vale /var/www/html/ci/application/controllers/B_up_xml_controller1.php 583
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: vale /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: vale /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 625
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 14:26:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-22 14:28:56 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:28:56 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:28:56 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 14:28:56 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:28:56 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:28:56 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:28:56 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:31:46 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:31:46 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 14:31:46 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:31:46 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:31:46 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:31:46 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:31:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:33:29 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:33:29 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 14:33:29 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:33:29 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:33:29 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:33:29 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:36:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:36:13 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:36:13 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 14:36:13 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:36:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:36:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:36:13 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:37:53 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:37:53 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:37:53 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:37:53 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:37:53 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:37:53 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:39:16 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:39:16 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:39:16 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:39:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:39:16 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:39:16 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:39:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:41:58 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:41:58 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-22 14:41:58 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 14:41:58 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:41:58 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:41:58 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:41:58 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:42:54 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:42:54 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 14:42:54 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:42:54 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-22 14:42:54 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 616
ERROR - 2015-09-22 14:42:54 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:43:50 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-22 14:43:50 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 14:43:50 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-22 14:43:50 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 698
ERROR - 2015-09-22 14:46:21 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 14:46:21 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 14:46:21 --> Severity: Notice --> Undefined variable: string_d_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 14:46:21 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 14:46:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 14:58:46 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 14:58:46 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-22 14:58:46 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 14:58:46 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 14:58:46 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 14:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:01:49 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:01:49 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-22 15:01:49 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 15:01:49 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 15:01:49 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:01:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:02:28 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:02:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-22 15:02:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 15:02:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 15:02:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:02:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:03:29 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:03:29 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-22 15:03:29 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 15:03:29 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 15:03:29 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:03:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-22 15:06:49 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:06:49 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:07:23 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:07:23 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:08:35 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:08:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:11:40 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:14:27 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:23:11 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:23:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 591
ERROR - 2015-09-22 15:23:11 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:23:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:25:15 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:25:15 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:25:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 15:25:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 15:25:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 591
ERROR - 2015-09-22 15:25:15 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:27:34 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-22 15:27:34 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:27:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 15:27:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 15:27:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 591
ERROR - 2015-09-22 15:27:34 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:27:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:28:57 --> Severity: Notice --> Undefined variable: var1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:28:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-22 15:28:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-22 15:28:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 591
ERROR - 2015-09-22 15:28:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-22 15:32:18 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:32:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 592
ERROR - 2015-09-22 15:32:18 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 15:32:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 15:33:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 15:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-22 15:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:35:46 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:36:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:36:49 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:36:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:37:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:37:17 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:37:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:38:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:38:36 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:38:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:40:07 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 15:40:07 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:41:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:41:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:41:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:41:32 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:41:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:42:48 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:43:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:43:12 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:43:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:44:21 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:44:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:44:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:44:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 15:44:21 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:44:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-22 15:48:47 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 569
ERROR - 2015-09-22 15:48:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:48:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:48:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 15:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:50:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 15:50:47 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 624
ERROR - 2015-09-22 15:52:22 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:52:22 --> Severity: Notice --> Undefined variable: c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 591
ERROR - 2015-09-22 15:52:22 --> Severity: Notice --> Undefined variable: c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 593
ERROR - 2015-09-22 15:52:22 --> Severity: Notice --> Undefined variable: c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 15:52:22 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 624
ERROR - 2015-09-22 15:52:53 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 574
ERROR - 2015-09-22 15:53:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:53:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:53:16 --> Severity: Notice --> Undefined variable: c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 591
ERROR - 2015-09-22 15:53:16 --> Severity: Notice --> Undefined variable: c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 593
ERROR - 2015-09-22 15:53:16 --> Severity: Notice --> Undefined variable: c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-22 15:53:16 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 624
ERROR - 2015-09-22 15:54:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:54:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:54:42 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 624
ERROR - 2015-09-22 15:55:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:55:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:58:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 15:58:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:05:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:05:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:11:25 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/views/b_xmlcaso2_view.php 116
ERROR - 2015-09-22 16:12:08 --> Severity: Parsing Error --> syntax error, unexpected 'as' (T_AS), expecting ')' /var/www/html/ci/application/views/b_xmlcaso2_view.php 116
ERROR - 2015-09-22 16:12:46 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/views/b_xmlcaso2_view.php 116
ERROR - 2015-09-22 16:30:54 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:30:54 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:37:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:37:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-22 16:43:28 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 16:45:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 16:45:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 16:45:20 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 16:45:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 16:48:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 16:48:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 16:48:36 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 16:48:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 584
ERROR - 2015-09-22 16:56:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 16:56:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 17:40:30 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 579
ERROR - 2015-09-22 17:42:27 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 579
ERROR - 2015-09-22 17:43:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:43:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-22 17:52:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 576
ERROR - 2015-09-22 18:21:13 --> Query error: Unknown column 'descrip' in 'field list' - Invalid query: INSERT INTO `productos` (`descrip`, `val_unit`) VALUES ('4', '0001')
ERROR - 2015-09-22 18:55:40 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-22 18:59:39 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-22 19:00:00 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 499
ERROR - 2015-09-22 19:27:27 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-22 19:40:03 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-22 19:41:02 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-22 19:53:18 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-22 20:01:07 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-22 20:01:44 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
