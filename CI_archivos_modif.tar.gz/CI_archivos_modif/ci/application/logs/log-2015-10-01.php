<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-01 13:05:41 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 70
ERROR - 2015-10-01 13:10:03 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 70
ERROR - 2015-10-01 13:14:00 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 71
ERROR - 2015-10-01 13:34:51 --> Severity: Notice --> Undefined variable: mysqli /var/www/html/ci/application/models/B_up_xml_model_mejor.php 50
ERROR - 2015-10-01 13:34:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/ci/application/models/B_up_xml_model_mejor.php 50
ERROR - 2015-10-01 13:36:23 --> Severity: Notice --> Undefined variable: mysqli_insert_id /var/www/html/ci/application/models/B_up_xml_model_mejor.php 50
ERROR - 2015-10-01 13:56:10 --> Severity: Warning --> mysqli_insert_id() expects parameter 1 to be mysqli, string given /var/www/html/ci/application/models/B_up_xml_model_mejor.php 51
ERROR - 2015-10-01 13:57:21 --> Severity: Warning --> mysqli_insert_id() expects parameter 1 to be mysqli, string given /var/www/html/ci/application/models/B_up_xml_model_mejor.php 51
ERROR - 2015-10-01 14:48:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 291
ERROR - 2015-10-01 14:49:04 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 291
ERROR - 2015-10-01 14:49:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 291
ERROR - 2015-10-01 14:49:56 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 291
ERROR - 2015-10-01 14:50:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 291
ERROR - 2015-10-01 14:50:34 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 291
ERROR - 2015-10-01 14:52:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-01 14:52:34 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-01 14:52:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-01 14:53:07 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-01 14:54:41 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-01 15:04:10 --> Query error: Duplicate entry 'NOR041213MX4' for key 'PRIMARY' - Invalid query: INSERT INTO `proveedor` (`id_rfc`, `rfc_nom`, `calle`, `no_ext`, `no_int`, `colonia`, `referen`, `mun`, `estado`, `pais`, `cp`, `id_uuid`) VALUES ('NOR041213MX4', 'NORDATA, S.A. DE C.V.', 'AV. Morones Prieto 1500', 'Piso 1', 'Suite 101', 'Nuevas Colonias', 'CENTRO CONVEX EDIFICIO JARDINES', 'MONTERREY', 'N.L.', 'México', '64710', '4FFB3E12-5CF2-AA48-B533-986FAC14F7DA')
ERROR - 2015-10-01 15:12:51 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:20:44 --> Severity: Notice --> Undefined variable: consulta /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:21:09 --> Severity: Notice --> Undefined variable: consulta /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:23:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:27:55 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:27:55 --> Severity: Notice --> Undefined variable: consulta /var/www/html/ci/application/controllers/B_up_xml_controller2.php 334
ERROR - 2015-10-01 15:27:55 --> Severity: Error --> Call to a member function result_array() on null /var/www/html/ci/application/controllers/B_up_xml_controller2.php 334
ERROR - 2015-10-01 15:28:14 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:28:14 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:28:14 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:28:14 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:28:14 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:28:14 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:28:14 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:30:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:30:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:32:04 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:32:04 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:32:04 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:32:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:34:23 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:34:23 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:34:23 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:34:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:34:23 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 336
ERROR - 2015-10-01 15:34:23 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 337
ERROR - 2015-10-01 15:34:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 338
ERROR - 2015-10-01 15:43:58 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:43:58 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/ci/application/controllers/B_up_xml_controller2.php 335
ERROR - 2015-10-01 15:44:36 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-01 15:44:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:44:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:44:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:44:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:20 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/ci/application/controllers/B_up_xml_controller2.php 335
ERROR - 2015-10-01 15:45:44 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller2.php 335
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:45:57 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:26 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:46:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
ERROR - 2015-10-01 15:47:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 339
