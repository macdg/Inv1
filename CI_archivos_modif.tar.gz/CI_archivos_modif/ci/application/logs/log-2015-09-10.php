<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-10 10:46:31 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:05:50 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:07:04 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 776
ERROR - 2015-09-10 11:13:25 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-10 11:20:32 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 780
ERROR - 2015-09-10 11:33:38 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-10 11:33:38 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 780
ERROR - 2015-09-10 11:35:26 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-10 11:35:26 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 782
ERROR - 2015-09-10 11:36:26 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-10 11:39:44 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-10 11:39:44 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `unidad`, `modelo`, `descripcion`, `valorunitario`, `fecha_ingreso`, `noserie`, `nopieza`) VALUES (Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2015-09-10 11:41:23 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:43:24 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:44:01 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:44:58 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:45:05 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:49:28 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 778
ERROR - 2015-09-10 11:50:15 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 11:59:24 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 775
ERROR - 2015-09-10 12:04:11 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 779
ERROR - 2015-09-10 12:05:46 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 12:23:17 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:23:17 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:23:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:23:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:23:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:23:17 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:23:57 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:23:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:23:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:23:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:23:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:23:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:23:57 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:25:21 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:25:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:25:21 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:25:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:25:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:25:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:25:21 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:29:13 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:29:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:29:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:29:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:29:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:29:13 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:29:35 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 12:29:47 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:29:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:29:47 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:29:47 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:29:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:29:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:29:47 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:33:45 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 654
ERROR - 2015-09-10 12:34:09 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:34:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:34:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:34:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:34:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:34:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:34:09 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:35:00 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:35:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:35:00 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:35:00 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:35:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:35:00 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:35:00 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:35:09 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:35:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:35:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:35:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:35:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:35:09 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:46:03 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:46:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 331
ERROR - 2015-09-10 12:46:03 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-10 12:46:03 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 435
ERROR - 2015-09-10 12:46:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 436
ERROR - 2015-09-10 12:46:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-10 12:46:03 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 12:57:18 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 12:57:29 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 13:02:22 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 486
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 488
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 490
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 493
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 507
ERROR - 2015-09-10 13:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 507
ERROR - 2015-09-10 13:08:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 487
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 489
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 491
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 494
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 506
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 508
ERROR - 2015-09-10 13:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 508
ERROR - 2015-09-10 13:10:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 506
ERROR - 2015-09-10 13:17:19 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 477
ERROR - 2015-09-10 13:17:56 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 477
ERROR - 2015-09-10 13:18:18 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 477
ERROR - 2015-09-10 13:33:40 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 341
ERROR - 2015-09-10 13:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 341
ERROR - 2015-09-10 13:33:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 444
ERROR - 2015-09-10 13:33:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 445
ERROR - 2015-09-10 13:33:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 446
ERROR - 2015-09-10 13:33:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 447
ERROR - 2015-09-10 13:38:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 259
ERROR - 2015-09-10 13:38:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 13:41:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 259
ERROR - 2015-09-10 13:41:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 13:42:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 259
ERROR - 2015-09-10 13:42:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:04:37 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 269
ERROR - 2015-09-10 14:06:25 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 269
ERROR - 2015-09-10 14:06:38 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 292
ERROR - 2015-09-10 14:08:44 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 267
ERROR - 2015-09-10 14:08:56 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 267
ERROR - 2015-09-10 14:09:33 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 267
ERROR - 2015-09-10 14:30:22 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 267
ERROR - 2015-09-10 14:31:29 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-10 14:32:19 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 288
ERROR - 2015-09-10 14:36:46 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 265
ERROR - 2015-09-10 14:41:09 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:41:09 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:41:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 14:41:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 14:41:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 14:41:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 14:41:09 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 14:41:34 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:41:34 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:41:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 14:41:34 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 14:41:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 14:41:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 14:41:34 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 14:44:49 --> Severity: Notice --> Undefined variable: result3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:44:49 --> Severity: Notice --> Undefined variable: cont_r3 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 261
ERROR - 2015-09-10 14:44:49 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 14:44:49 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 14:44:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 14:44:49 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 14:44:49 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 14:48:56 --> Query error: Duplicate entry '4FFB3E12-5CF2-AA48-B533-98' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', '1', 'PIEZA', 'TELEFONO SIP YEALINK MOD T26P DISPLAY LCD 3 TECLAS LINEA', '112.00')
ERROR - 2015-09-10 15:03:52 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 15:03:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 15:03:52 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 15:03:52 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 15:03:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 15:03:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 15:03:52 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 15:04:55 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 15:04:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 15:04:55 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 15:04:55 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 15:04:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 15:04:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 15:04:55 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 15:08:49 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 15:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 15:08:49 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 15:08:49 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 15:08:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 15:08:49 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 15:08:49 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:04:54 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 940
ERROR - 2015-09-10 16:05:43 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 940
ERROR - 2015-09-10 16:09:07 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:13:14 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:13:17 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:13:57 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:16:13 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:17:02 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:17:26 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:17:50 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller1.php 940
ERROR - 2015-09-10 16:18:21 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:18:30 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:18:34 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:27:28 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:33:13 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:33:46 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting ')' /var/www/html/ci/application/models/B_up_xml_model.php 90
ERROR - 2015-09-10 16:34:10 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 16:34:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 16:34:10 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 16:34:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:34:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:34:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:34:10 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:40:58 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 16:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 16:40:58 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 16:40:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:40:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:40:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:40:58 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:47:26 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 16:47:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-10 16:47:26 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 16:47:26 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:47:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:47:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:47:26 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:50:11 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 272
ERROR - 2015-09-10 16:50:50 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:50:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:50:50 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:50:50 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:50:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:50:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 16:50:50 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:52:13 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:52:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:52:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:52:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:52:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 16:52:13 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:55:15 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:55:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:55:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:55:15 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:55:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:55:15 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 16:55:15 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:56:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:56:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:56:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:56:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:56:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:56:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 16:56:05 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:56:13 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:56:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:56:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:56:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:56:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 16:56:13 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 16:58:10 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:58:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 16:58:10 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 16:58:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 16:58:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 16:58:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 16:58:10 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:09:58 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:09:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:09:58 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:09:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 17:09:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 17:09:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 17:09:58 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:12:14 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:12:14 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:12:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 17:12:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 17:12:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 17:12:14 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:17:19 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:17:19 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:17:19 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 17:17:19 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 17:17:19 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 17:17:19 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:18:07 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:18:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:18:07 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:18:07 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 17:18:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 17:18:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 17:18:07 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:26:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 247
ERROR - 2015-09-10 17:26:40 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:26:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:26:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:26:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 17:26:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 17:26:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 17:26:40 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:35:08 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-10 17:35:19 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-10 17:35:33 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 266
ERROR - 2015-09-10 17:36:58 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:36:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 17:36:58 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:36:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 17:36:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 17:36:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 17:36:58 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 17:51:01 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 17:51:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 17:51:01 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 17:51:01 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 17:51:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 17:51:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 17:51:01 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:00:44 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:00:44 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 18:00:44 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 18:00:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 18:00:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:00:44 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:05:06 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:05:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 18:05:06 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 18:05:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 18:05:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:05:06 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:05:20 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:05:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:05:20 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 18:05:20 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 18:05:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 18:05:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:05:20 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:06:49 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 345
ERROR - 2015-09-10 18:06:49 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 448
ERROR - 2015-09-10 18:06:49 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 449
ERROR - 2015-09-10 18:06:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-10 18:06:49 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:06:49 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:11:48 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:11:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:11:48 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:11:48 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:11:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:11:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:11:48 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:15:12 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:15:12 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:15:12 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:15:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:15:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:15:12 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:15:25 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:15:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:15:25 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:15:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:15:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:15:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:15:25 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:20:27 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-10 18:20:27 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-10 18:20:27 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 218
ERROR - 2015-09-10 18:20:27 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 237
ERROR - 2015-09-10 18:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-10 18:20:27 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 269
ERROR - 2015-09-10 18:20:42 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:20:42 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:20:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:20:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:20:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:20:42 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:30:54 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:30:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:30:54 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:30:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:30:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:30:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:30:54 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:45:54 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:45:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:45:54 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:45:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:45:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:45:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:45:54 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:46:11 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:46:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:46:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:46:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:46:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:46:11 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:49:45 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:49:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:49:45 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:49:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:49:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:49:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:49:45 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 18:50:03 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 18:50:03 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 18:50:03 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 18:50:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 18:50:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 18:50:03 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 19:00:00 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 19:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 19:00:00 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 19:00:00 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 19:00:00 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 19:00:00 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 19:00:00 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-10 19:03:20 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 19:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 348
ERROR - 2015-09-10 19:03:20 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-10 19:03:20 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-10 19:03:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-10 19:03:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-10 19:03:20 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
