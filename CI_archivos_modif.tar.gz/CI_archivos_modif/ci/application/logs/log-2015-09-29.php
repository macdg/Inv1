<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-29 14:00:45 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 13
ERROR - 2015-09-29 14:00:45 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 21
ERROR - 2015-09-29 14:00:45 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 39
ERROR - 2015-09-29 14:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 39
ERROR - 2015-09-29 14:00:45 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 77
ERROR - 2015-09-29 14:07:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 11
ERROR - 2015-09-29 14:07:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 19
ERROR - 2015-09-29 14:07:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:07:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 75
ERROR - 2015-09-29 14:07:11 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 11
ERROR - 2015-09-29 14:07:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 19
ERROR - 2015-09-29 14:07:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:07:11 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 75
ERROR - 2015-09-29 14:13:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 11
ERROR - 2015-09-29 14:13:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 19
ERROR - 2015-09-29 14:13:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:13:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 75
ERROR - 2015-09-29 14:13:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 11
ERROR - 2015-09-29 14:13:25 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 19
ERROR - 2015-09-29 14:13:25 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:13:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 75
ERROR - 2015-09-29 14:20:40 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 11
ERROR - 2015-09-29 14:20:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 19
ERROR - 2015-09-29 14:20:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:20:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:20:40 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 75
ERROR - 2015-09-29 14:22:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 11
ERROR - 2015-09-29 14:22:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 19
ERROR - 2015-09-29 14:22:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 37
ERROR - 2015-09-29 14:22:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 75
ERROR - 2015-09-29 14:27:03 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 14:27:03 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 14:27:03 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 14:27:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 14:27:03 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 76
ERROR - 2015-09-29 14:41:20 --> Severity: Parsing Error --> syntax error, unexpected 'noserie' (T_STRING), expecting ')' /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 60
ERROR - 2015-09-29 14:42:39 --> Severity: Parsing Error --> syntax error, unexpected 'noserie' (T_STRING), expecting ')' /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 60
ERROR - 2015-09-29 14:43:43 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 60
ERROR - 2015-09-29 14:44:32 --> Severity: Parsing Error --> syntax error, unexpected 'noserie' (T_STRING), expecting ')' /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 60
ERROR - 2015-09-29 14:50:10 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Log.php 161
ERROR - 2015-09-29 14:51:39 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Log.php 161
ERROR - 2015-09-29 14:53:26 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Log.php 161
ERROR - 2015-09-29 14:57:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 14:57:41 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 14:57:41 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 14:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 14:57:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:00:53 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:00:53 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:00:53 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:00:53 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:06:23 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:06:23 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:06:23 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:06:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:06:23 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:08:24 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:08:24 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:08:24 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:08:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:08:24 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:08:55 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:08:55 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:08:55 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:08:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:08:55 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:09:04 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:09:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:09:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:09:04 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:10:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:10:41 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:10:41 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:10:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:10:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:14:11 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:14:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:14:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:14:11 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:14:56 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:14:56 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:14:56 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:14:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:14:56 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:16:19 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:16:19 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:16:19 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:16:19 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:17:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:17:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:17:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:17:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:17:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:19:19 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 317
ERROR - 2015-09-29 15:21:46 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Log.php 161
ERROR - 2015-09-29 15:32:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:32:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:32:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:32:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:35:06 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:35:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:35:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:35:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:35:06 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:36:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:36:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:36:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:36:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 15:38:31 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 12
ERROR - 2015-09-29 15:38:31 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 20
ERROR - 2015-09-29 15:38:31 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 38
ERROR - 2015-09-29 15:38:31 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view2_mejor.php 74
ERROR - 2015-09-29 16:01:57 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:05:00 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:05:51 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:05:56 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:10:42 --> Severity: Parsing Error --> syntax error, unexpected '>' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:11:07 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:12:00 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 16:12:11 --> Severity: Parsing Error --> syntax error, unexpected '"Error"' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
ERROR - 2015-09-29 19:04:20 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 301
