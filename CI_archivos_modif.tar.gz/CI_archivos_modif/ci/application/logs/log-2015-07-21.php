<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-21 14:11:52 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:11:52 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:13:15 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:13:15 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:14:35 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:14:35 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:16:21 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/ci/system/core/Common.php 105
ERROR - 2015-07-21 14:17:06 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/ci/application/views/d_new_viewA.php 18
ERROR - 2015-07-21 14:17:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:17:26 --> Severity: Error --> Cannot access empty property /var/www/ci/application/views/d_new_viewA.php 13
ERROR - 2015-07-21 14:18:10 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:18:10 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:18:27 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:18:27 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:19:42 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:19:42 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 14:25:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:25:09 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:26:38 --> Severity: Warning --> fopen(mi_archivo_1): failed to open stream: No such file or directory /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:27:28 --> Severity: Warning --> fopen(/root/CertificadosUnion1/mi_archivo_1): failed to open stream: No such file or directory /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:30:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-21 14:30:30 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:30:30 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:31:46 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-21 14:31:46 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:31:46 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:35:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-21 14:35:24 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:35:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:35:24 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:35:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 89
ERROR - 2015-07-21 14:35:25 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 90
ERROR - 2015-07-21 14:35:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:35:25 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:37:28 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:37:28 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:37:28 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 14:37:28 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 14:37:41 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:37:41 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:37:41 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 14:37:41 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 14:38:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:38:42 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:38:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 14:38:42 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 14:38:42 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 14:40:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:40:37 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:40:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 14:40:37 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 14:40:37 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 14:42:18 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:42:18 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 14:42:18 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 14:42:18 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 96
ERROR - 2015-07-21 14:42:18 --> Severity: Warning --> fopen(): Filename cannot be empty /var/www/ci/application/views/d_new_view.php 96
ERROR - 2015-07-21 14:44:19 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:44:19 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:45:44 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:45:44 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:50:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:50:57 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:51:58 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:51:58 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:52:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:52:00 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:55:54 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:55:54 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:56:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:56:51 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 14:56:53 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 14:56:53 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 15:04:09 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 15:04:09 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 15:04:09 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 15:04:09 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 15:04:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 15:04:10 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 15:04:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 15:04:10 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 15:38:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 15:38:42 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 15:38:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 15:38:42 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 15:38:44 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 15:38:44 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 15:38:44 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 15:38:44 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 15:40:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 15:40:30 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 15:40:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 15:40:30 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 17:05:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 17:05:40 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:05:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 17:05:40 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 17:05:52 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 91
ERROR - 2015-07-21 17:05:52 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:05:52 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 94
ERROR - 2015-07-21 17:05:52 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 95
ERROR - 2015-07-21 17:09:52 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:09:52 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:14:54 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:14:54 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:29:02 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:29:02 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:31:44 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:31:44 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:31:56 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:31:56 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:32:44 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:32:44 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:35:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:35:51 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:42:11 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:42:11 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:43:52 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 17:43:52 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 17:43:52 --> Severity: Notice --> Undefined variable: archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 17:43:52 --> Severity: Notice --> Undefined variable: archivo_2 /var/www/ci/application/views/d_new_viewA.php 15
ERROR - 2015-07-21 17:43:52 --> Severity: Notice --> Undefined variable: archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 17:43:52 --> Severity: Notice --> Undefined variable: archivo_2 /var/www/ci/application/views/d_new_viewA.php 15
ERROR - 2015-07-21 18:03:04 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/ci/application/views/d_new_view.php 92
ERROR - 2015-07-21 18:03:04 --> Severity: Notice --> Undefined index: mi_archivo_2 /var/www/ci/application/views/d_new_view.php 93
ERROR - 2015-07-21 18:03:04 --> Severity: Notice --> Undefined variable: archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 18:03:04 --> Severity: Notice --> Undefined variable: archivo_2 /var/www/ci/application/views/d_new_viewA.php 15
ERROR - 2015-07-21 18:03:04 --> Severity: Notice --> Undefined variable: archivo_1 /var/www/ci/application/views/d_new_viewA.php 14
ERROR - 2015-07-21 18:03:04 --> Severity: Notice --> Undefined variable: archivo_2 /var/www/ci/application/views/d_new_viewA.php 15
