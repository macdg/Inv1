<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-05 10:37:04 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 347
ERROR - 2015-10-05 10:40:50 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-05 10:41:33 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-05 11:41:01 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 288
ERROR - 2015-10-05 11:41:01 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:41:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:41:01 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 293
ERROR - 2015-10-05 11:41:01 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-05 11:41:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 288
ERROR - 2015-10-05 11:41:13 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:41:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:41:13 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 293
ERROR - 2015-10-05 11:41:13 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-05 11:44:40 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 288
ERROR - 2015-10-05 11:44:40 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:44:40 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 293
ERROR - 2015-10-05 11:44:40 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-05 11:45:21 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller2.php 288
ERROR - 2015-10-05 11:45:21 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-05 11:45:21 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 293
ERROR - 2015-10-05 11:45:21 --> Severity: Notice --> Undefined variable: varx /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-05 11:51:36 --> Severity: Error --> Maximum execution time of 1000 seconds exceeded /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-05 11:52:36 --> Severity: Error --> Maximum execution time of 1000 seconds exceeded /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-05 11:54:34 --> Severity: Error --> Maximum execution time of 1000 seconds exceeded /var/www/html/ci/application/controllers/B_up_xml_controller2.php 326
ERROR - 2015-10-05 13:20:12 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 373
ERROR - 2015-10-05 13:21:27 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-05 13:22:32 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 333
ERROR - 2015-10-05 13:50:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:50:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:50:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:50:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:50:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:50:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:50:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 312
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:52:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:25 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:53:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:33 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:33 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:33 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:55:33 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:57:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:58:50 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 308
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 13:59:42 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:00:28 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 308
ERROR - 2015-10-05 14:03:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:03:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:03:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:03:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:03:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:03:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:03:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:05:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:07:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:13:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 313
ERROR - 2015-10-05 14:29:57 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 392
ERROR - 2015-10-05 14:37:47 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 398
ERROR - 2015-10-05 14:38:03 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/controllers/B_up_xml_controller2.php 398
ERROR - 2015-10-05 14:38:09 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/controllers/B_up_xml_controller2.php 398
ERROR - 2015-10-05 17:46:16 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (NULL, NULL)
ERROR - 2015-10-05 17:48:30 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 431
ERROR - 2015-10-05 17:54:57 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 431
ERROR - 2015-10-05 18:00:28 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 435
ERROR - 2015-10-05 18:00:40 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 466
ERROR - 2015-10-05 18:01:08 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`cantidad`, `noserie`) VALUES (NULL, NULL)
ERROR - 2015-10-05 18:03:16 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 470
ERROR - 2015-10-05 18:18:36 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 356
ERROR - 2015-10-05 18:18:54 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 374
ERROR - 2015-10-05 19:34:44 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 402
ERROR - 2015-10-05 19:35:07 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 402
ERROR - 2015-10-05 19:35:36 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 403
ERROR - 2015-10-05 19:35:47 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 402
ERROR - 2015-10-05 19:43:34 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 397
