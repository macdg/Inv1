<!DOCTYPE html>
<html>
<head>
	<title>Error:Trabajando Página</title>
</head>
<body>
<h2>Tambien sustituye de manera a amigable a la página de ERROR [404] </h2>
<?php
echo ('Página en Construcción');
?>
<IMG SRC="<?php echo base_url('images/estamos-trabajando.jpg')?>"><IMG SRC="<?php echo base_url('images/trabajando_web.jpg')?>"><IMG SRC="<?php echo base_url('images/estamos-trabajando.jpg')?>">
<IMG SRC="<?php echo base_url('images/trabajando_web.jpg')?>">
<?php echo ('Página en Construcción');?>
<IMG SRC="<?php echo base_url('images/estamos-trabajando.jpg')?>">
<IMG SRC="<?php echo base_url('images/trabajando_web.jpg')?>">
</body>
</html>