<<!DOCTYPE html>
<html>
<head>
	<title>Recibido</title>
</head>
<body>

El archivo recibido es este...

<?php
//---------------------------------------------
//Esto divide al script original. Inicio de Script.

echo '<br>'.$archivo_1.'<br>';
echo '<br>'.$archivo_2.'<br>';

// $tratando_arch = fopen($mi_archivo_1, "r") or die("No puedo abrir el archivo!");
// echo fread($tratando_arch, filesize($mi_archivo_1));
// fclose($mi_archivo_1);

// $tratando_arch = fopen($mi_archivo_2, "r") or die("No puedo abrir el archivo!");
// echo fread($tratando_arch, filesize($mi_archivo_2));
// fclose($mi_archivo_2);

//Esto divide al script original. Fin de Script.
//-----------------------------------------------
?>

</body>
</html>