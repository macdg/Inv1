<?php
$this->load->helper('html');

echo br(2);
?>
<?php//********************************************?>

<?php echo heading('XML 2', 2); ?>
<TABLE BORDER=1 WIDTH="700">
<TR>
<TD WIDTH="400">UUID:  <?php echo $uuid; ?></TD>
</TR>
</TABLE>


<TABLE BORDER=1 WIDTH="900">
<TR>
<?php
$cuantos_cant=count($cant_1);
for ($i=0; $i<$cuantos_cant; $i++){   ?>
<TD WIDTH="300">Cantidad:   <?php echo $cant_1[$i]; };?> </TD>
</TR>
</TABLE>


<TABLE BORDER=1 WIDTH="900">
<TR>
<?php
$cuantos_desc=count($descrip_1);
for ($i=0; $i<$cuantos_desc; $i++){   ?>
<TD WIDTH="400">Descripción:<br><?php echo $descrip_1[$i];   }  ?></TD>
</TR>
</TABLE>
<BR><BR><HR>

<?php echo heading('Ingresar Productos', 2); ?>

<?php
//********************************************


foreach ($descrip_1 as $key => $value) {
   //echo '<br><br>$descrip_1 KEY:= '.$key.'  $descrip_1 VALUE:= '.$value;
$des[]=$value;
$cuantos_desc=count($descrip_1);
}

//echo br(1);

foreach ($cant_1 as $key => $value) {
   //echo '<br><br>$cant_1 KEY:= '.$key.'  $cant_1 VALUE:= '.$value;

echo br(1).'LINEA DE PRODUCTO<hr>';
  for ($k=1; $k<=$value; $k++){
?>
<form method="post" accept-charset="utf-8" action="http://localhost/ci/index.php/up_xml_controller1/index" />
<?php

echo form_label('Ingrese Cantidad: ', 'cantidad');
 $datos_in_cantidad = array(
              'name'        => 'cantidad',
              'id'          => 'cantidad',
              'value'       => '',
              'maxlength'   => '',
              'size'        => '',
              'style'       => 'width:30',
            );
echo form_input($datos_in_cantidad);
echo br(1);

echo form_label('Ingrese Unidad: ', 'unidad');
 $datos_in_unidad = array(
              'name'        => 'unidad',
              'id'          => 'unidad',
              'value'       => '',
              'maxlength'   => '',
              'size'        => '',
              'style'       => 'width:90',
            );
echo form_input($datos_in_unidad);
echo br(1);

echo form_label('Ingrese Modelo: ', 'modelo');
 $datos_in_modelo = array(
              'name'        => 'modelo',
              'id'          => 'modelo',
              'value'       => '',
              'maxlength'   => '',
              'size'        => '',
              'style'       => 'width:187',
            );
echo form_input($datos_in_modelo);
echo br(1);

echo form_label('Ingrese Descripción: ', 'descripcion');
$datos_in_descripcion = array(
             'name'        => 'descripcion',
             'id'          => 'descripcion',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:48%',
           );
echo form_input($datos_in_descripcion);
echo br(1);

echo form_label('Ingrese Valor Unitario: ', 'valorunitario');
$datos_in_valorunitario = array(
             'name'        => 'valorunitario',
             'id'          => 'valorunitario',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:10%',
           );

echo form_input($datos_in_valorunitario);
echo br(1);

echo form_label('Ingrese Fecha de Ingreso: ', 'fecha');
$datos_in_fecha = array(
             'name'        => 'fecha_ingreso',
             'id'          => 'fecha_ingreso',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:20%',
           );

echo form_input($datos_in_fecha);
echo br(1);

echo form_label('Ingrese Número de Serie: ', 'numserie');
$datos_in_numserie = array(
             'name'        => 'noserie',
             'id'          => 'noserie',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:100',
           );

echo form_input($datos_in_numserie);
echo br(1);

echo form_label('Ingrese Número de Pieza: ', 'pza');
$datos_in_pza = array(
             'name'        => 'nopieza',
             'id'          => 'nopieza',
             'value'       => '1',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:30',
           );

echo form_input($datos_in_pza);
echo br(1);

//echo '<br>Registro: '.$k.'  de: '.$value;
//echo form_close();
?><CENTER><?php
echo form_submit('Aceptar', 'Aceptar').form_reset('Reset', 'Reset');
?></CENTER><?php echo form_close();


  }


}
