<?php
require_once ('conexion_mysql.php');
?>
<html>
<head>
<meta http-equiv="Content=Type" content="text/html; charset=UTF=8">
<title>Prueba de conexión</title>
</head>
<body>
	<h2>Listado de comentarios en el Libro de Visitas</h2>


<?php
$tra     = new Trabajo();
$visitas = $tra->get_visitas();

for ($i = 0; $i < sizeof($visitas); $i++) {
	echo $visitas[$i]['nombre_persona'];
	echo "&nbsp;&nbsp;||&nbsp;&nbsp;";
	echo $visitas[$i]['texto'];
	echo "<br>";
}
//****************************************************
echo '<hr>';
$tra     = new Trabajo();
$visitas = $tra->get_visitas1();

for ($i = 0; $i < sizeof($visitas); $i++) {
	echo $visitas[$i]['nombre_persona'];
	echo "&nbsp;&nbsp;||&nbsp;&nbsp;";
	echo $visitas[$i]['texto'];
	echo "<br>";
}

?>


</body>
</html>