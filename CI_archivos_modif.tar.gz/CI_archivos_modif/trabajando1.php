<!DOCTYPE html>
<html>
<head>
	<title>Trabajando Página</title>
</head>
<body>

<?php
//error_reporting(E_ALL^E_WARNING^E_NOTICE);
echo ('Alcance de las variables'.'<br>');

function regresa_rtrn() {

	$y = 1;
	echo "Esto es el return de una variable sin evaluar".$y;
	return $y;
}

$o = regresa_rtrn();
echo '<br>'.'Este es el vlor de ejemplo "return":'.$o.'<br>';

$x = 4;
$y = 2;
echo alcance($x, $y);

function alcance($a, $b) {

	echo '<br>';
	$c = 0;
	$c = $a+$b;

	echo 'Esto se muestra en el alcance, en "a:'.$a.'"'.' y en "b:'.$b.'"'.'';
	echo '<br>'.$a.$b.$c;
	return $c;

}

echo alcance(1, 2);
$j = alcance(1, 2);
echo '<br><br>';
echo alcance(3, 4);
$k = alcance(3, 4);
echo '<br><br>';
echo alcance(5, 6);
$l = alcance(5, 6);
echo '<br><br>';

echo '<br>';
echo 'Esto vale despues de terminar la funcion a:'.$j.' b:'.$k.' c:'.$l;

echo '<br>'.'----------------------------------------------------------------------'.'<br>';
phpinfo();

?>
<form method="post" action="accion.php" enctype="multipart/form-data">

Ingresa el archivo:

<input name="imagen" type="file" />

</form>


<?php
echo "Today is ".date("Y-m-d")."<br>";
echo "The time is ".date("h:i:sa");

?>
</body>
</html>
