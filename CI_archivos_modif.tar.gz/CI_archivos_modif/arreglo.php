<?php

$codeigniter=array();
print_r($codeigniter);
var_dump($codeigniter);
echo "<br><br>";
$horario=array('1' => array('deporte' =>'1',
							'ocio'=>'2',
							'desayuno'=>'3'
							),
				'2'=>array('deporte' =>'Baloncesto',
							'ocio'=>'cine',
							'comida'=>'3'
							)
			);
print_r($horario);
var_dump($horario);


?>