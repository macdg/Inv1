<?php
require_once ('conexion_lvisitas.php');
?>
<!DOCTYPE HTML PUBLIC "~//W3C // DTD HTML 4.01 Transitional // EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insertar resgistros con PHP POO </title>
<!-- Nota:                                        Las rutas de POO es igual sin diagonales al principio y al final.  -->
<script type="text/javascript" language="javascript" src="js/funciones.js"> </script>
</head>

<body onload="limpiar();">
<!-- <center> -->
<form name="form" action="ingresar.php" method="post">
<table width="600" align="center">

<tr>
<td align="center" width ="400" valign="top" colspan="2">
<h2>Ingrese su comentario</h2>
</td>
</tr>

<tr>
<td valign="top" align="right">
Su nombre
</td>
<td valign="top" align="left">
<input type="text" name="nom" />
</td>
</tr>

<tr>
<td valign="top" align="right">
Su mensaje
</td>
<td valign="top" align="left">
<textarea name="texto" cols="50" row="5"> </textarea> <type="text" name="nom" />
</td>
</tr>

<tr>
<td valign="top" width="400" align="center" colspan="2">
<hr/>
<input type="button" value="Escribir" title="Escribir" onclick="validar();" />
</td>
</tr>

</table>
</form>

<table align="center" width="700">
<tr>
<td width="700" valign="top" align="center" colspan="6">
<hr/>
</td>
</tr>



<tr style="background-color:#666666; color:#f0f0f0; font-weight:bold">
<td valign="top" align="center" width="150">
	Nombre
</td>
<td valign="top" align="center" width="350">
<div align="justify">
	Texto
</td>
<td valign="top" align="center" width="50">
	Fecha
</td>
<td valign="top" align="center" width="50">
	Hora
</td>
<td valign="top" align="center" width="50">

</td>

<td valign="top" align="center" width="50">

</td>




<?php
$tra = new Trabajo();
$reg = $tra->get_visitas();
for ($i = 0; $i < count($reg); $i++) {

	?>
	<tr style='background-color:#f0f0f0'>

	<td valign="top" align="center" width="150">
	<?php echo $reg[$i]['nombre_persona'];?>
	</td>
	<td valign="top" align="center" width="350">
	<div align="justify">
	<?php echo $reg[$i]['texto'];?>
	</td>
	<td valign="top" align="center" width="50">
	<?php echo $reg[$i]['fecha'];?>
	</td>
	<td valign="top" align="center" width="50">
	<?php echo $reg[$i]['hora'];?>
	</td>

	<td valign="top" align="center" width="50">
		<a href="javascript:void(0);" Onclick="window.location='editar.php?id=<?php echo $reg[$i]['id'];?>" title="Editar Registro"><img src="icono-editarpk"></a>
		<!-- Para mostrar el contenido de id, seria de la siguiente manera:
		<a href="editar.php?id=<?php// echo $reg[$i]['id'];?>" title="Editar Registro"><img src="icono-editarpk"></a>
		Pero como esto no es seguro Ocultamos el contenido a la vista en la barra de trabajo, como se muestra en la línea siguiente.
		Para ocultar el contenido de id, seria de esta manera:
		<a href="javascript:void(0);" Onclick="window.location='editar.php?id=<?php// echo $reg[$i]['id']';?>" title="Editar Registro"><img src="icono-editarpk"></a> -->

		</td>
		<td valign="top" align="center" width="50">
		<a href="" title="Eliminar Registro"><img src="eliminarpke"></a>
		</td>


	<?php }//Fin de For ?>
</center>
</body>
</html>
